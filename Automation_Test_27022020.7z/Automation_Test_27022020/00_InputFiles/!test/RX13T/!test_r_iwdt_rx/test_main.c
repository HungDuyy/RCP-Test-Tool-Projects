/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_main.c
* Description  : Runner of IWDT Unit test
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 12.06.2019 1.00     First release
***********************************************************************************************************************/

#include "platform.h"
#include "r_iwdt_rx_if.h"

#include "stdio.h"
#include "../!test/unity/unity_fixture.h"



TEST_GROUP_RUNNER(IWDT_TEST)
{
    RUN_TEST_CASE(IWDT_TEST, TG001_001);

    /* TG003_007 is test calling IWDT control before calling IWDT open.
	 * So, It must be run before running IWDT open tests*/
    RUN_TEST_CASE(IWDT_TEST, TG003_007);

    RUN_TEST_CASE(IWDT_TEST, TG002_001);
    RUN_TEST_CASE(IWDT_TEST, TG002_002);
    RUN_TEST_CASE(IWDT_TEST, TG002_003);
    RUN_TEST_CASE(IWDT_TEST, TG002_004);
    RUN_TEST_CASE(IWDT_TEST, TG002_005);
    RUN_TEST_CASE(IWDT_TEST, TG002_006);
    RUN_TEST_CASE(IWDT_TEST, TG002_007);
    RUN_TEST_CASE(IWDT_TEST, TG002_008);
    RUN_TEST_CASE(IWDT_TEST, TG002_009);
    RUN_TEST_CASE(IWDT_TEST, TG002_010);

    RUN_TEST_CASE(IWDT_TEST, TG003_001);
    RUN_TEST_CASE(IWDT_TEST, TG003_002);
    RUN_TEST_CASE(IWDT_TEST, TG003_003);
    RUN_TEST_CASE(IWDT_TEST, TG003_004);
    RUN_TEST_CASE(IWDT_TEST, TG003_005);
    RUN_TEST_CASE(IWDT_TEST, TG003_006);
}

static void RunTest()
{
    printf("Running IWDT Unit Tests...\n");

    RUN_TEST_GROUP(IWDT_TEST);
}

void main()
{
    UnityMain(0, 0, RunTest);

    printf("TEST DONE !!!\n");
}
