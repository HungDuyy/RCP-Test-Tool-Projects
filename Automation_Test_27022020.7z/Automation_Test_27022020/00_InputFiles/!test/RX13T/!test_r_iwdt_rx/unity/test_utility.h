#include <stdarg.h>
#include "platform.h"

#ifndef TEST_TEST_UTILITY_H_
#define TEST_TEST_UTILITY_H_

#define USER_PRINTF tu_printf
#define USER_SPRINTF tu_sprintf
#define USER_GETCHAR tu_getchar
#define USER_PUTCHAR tu_putchar

int tu_putchar(int output_char);
int tu_getchar(void);

int tu_sprintf(char *out, const char *format, ...);
int tu_printf(const char *format, ...);


#endif /* TEST_TEST_UTILITY_H_ */
