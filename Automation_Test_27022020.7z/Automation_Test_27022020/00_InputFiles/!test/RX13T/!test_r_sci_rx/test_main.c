/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_main.c
* Description     : Unity unit tests for SCI Module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 16.06.2017 1.00     First Release
*         : 07.07.2017 2.00     Improve test cases, add test cases for internal functions
*         : 07.12.2018 3.00     Support RX72T
*         : 18.04.2019 4.00     Support RX72M
*         : 08.06.2019 5.00     Support RX23W
*         : 28.08.2019 5.10     Support RX13T
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "platform.h"
#include "unity_fixture.h"
#include "r_sci_rx_private.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static void RunAllTests(void);

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/

TEST_GROUP_RUNNER(R_SCI_Open_Test)
{
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_001);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_002);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_003);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_004);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_005);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_006);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_007);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_008);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_009);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_010);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_011);
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_012);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_013);
#endif
#if defined (BSP_MCU_RX23W)
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_013);
#endif
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_014);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_015);
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_016);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_016);
#endif
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_017); // Test invalid channel 2
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_018);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_019);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_020);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_021);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_022);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_023);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_024);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_025);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_026);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_027);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_028);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_029);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_030);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_031);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_032);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_033);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_034);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_035);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_036);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_037);
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_038);
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_039);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_Open_Test, TG001_039);
#endif
}

TEST_GROUP_RUNNER(R_SCI_Close_Test)
{
    RUN_TEST_CASE(R_SCI_Close_Test, TG002_001);
    RUN_TEST_CASE(R_SCI_Close_Test, TG002_002);
    RUN_TEST_CASE(R_SCI_Close_Test, TG002_003);
    RUN_TEST_CASE(R_SCI_Close_Test, TG002_004);
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Close_Test, TG002_005);
#endif
}

TEST_GROUP_RUNNER(R_SCI_Send_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_001);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_002);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_003);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_004);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_005);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_006);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_007);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_008);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_009);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_010);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_011);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_012);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_013);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_014);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_015);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_016);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_017);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_018);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_001);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_002);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_003);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_004);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_005);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_006);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_007);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_008);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_009);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_010);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_011);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_012);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_013);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_014);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_015);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_016);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_017);
    RUN_TEST_CASE(R_SCI_Send_Test, TG003_018);
#endif
}

TEST_GROUP_RUNNER(R_SCI_Receive_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_001);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_002);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_003);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_004);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_005);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_006);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_007);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_008);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_009);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_010);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_011);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_012);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_013);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_014);
}
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_001);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_002);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_003);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_004);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_005);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_006);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_007);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_008);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_009);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_010);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_011);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_012);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_013);
    RUN_TEST_CASE(R_SCI_Receive_Test, TG004_014);
}
#endif

TEST_GROUP_RUNNER(R_SCI_SendReceive_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_001);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_002);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_003);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_004);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_005);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_006);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_007);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_008);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_009);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_010);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_011);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_012);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_013);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_001);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_002);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_003);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_004);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_005);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_006);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_007);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_008);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_009);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_010);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_011);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_012);
    RUN_TEST_CASE(R_SCI_SendReceive_Test, TG005_013);
#endif
}

TEST_GROUP_RUNNER(R_SCI_Control_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_001);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_002);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_003);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_004);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_005);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_006);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_007);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_008);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_009);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_010);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_011);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_012);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_013);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_014);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_015);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_016);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_017);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_018);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_019);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_020);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_021);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_022);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_023);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_024);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_025);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_026);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_027);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_028);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_029);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_001);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_002);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_003);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_004);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_005);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_006);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_007);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_008);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_009);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_010);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_011);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_012);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_013);
    RUN_TEST_CASE(R_SCI_Control_Test, TG006_014);
#endif
}

TEST_GROUP_RUNNER(R_SCI_GetVersion_Test)
{
    RUN_TEST_CASE(R_SCI_GetVersion_Test, TG007_001);
}

TEST_GROUP_RUNNER(txi_handler_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(txi_handler_Test, TG008_001);
    RUN_TEST_CASE(txi_handler_Test, TG008_002);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(txi_handler_Test, TG008_001);
    RUN_TEST_CASE(txi_handler_Test, TG008_002);
#endif
}

TEST_GROUP_RUNNER(rxi_handler_Test)
{
    RUN_TEST_CASE(rxi_handler_Test, TG009_001);
    RUN_TEST_CASE(rxi_handler_Test, TG009_002);
    RUN_TEST_CASE(rxi_handler_Test, TG009_003);
    RUN_TEST_CASE(rxi_handler_Test, TG009_004);
    RUN_TEST_CASE(rxi_handler_Test, TG009_005);
    RUN_TEST_CASE(rxi_handler_Test, TG009_006);
    RUN_TEST_CASE(rxi_handler_Test, TG009_007);
    RUN_TEST_CASE(rxi_handler_Test, TG009_008);
    RUN_TEST_CASE(rxi_handler_Test, TG009_009);
}

TEST_GROUP_RUNNER(eri_handler_Test)
{
    RUN_TEST_CASE(eri_handler_Test, TG010_001);
    RUN_TEST_CASE(eri_handler_Test, TG010_002);
    RUN_TEST_CASE(eri_handler_Test, TG010_003);
    RUN_TEST_CASE(eri_handler_Test, TG010_004);
    RUN_TEST_CASE(eri_handler_Test, TG010_005);
    RUN_TEST_CASE(eri_handler_Test, TG010_006);
}


TEST_GROUP_RUNNER(power_on_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(power_on_Test, TG011_001);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(power_on_Test, TG011_001);
#endif
}

TEST_GROUP_RUNNER(power_off_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(power_off_Test, TG012_001);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(power_off_Test, TG012_001);
#endif
}

TEST_GROUP_RUNNER(sci_init_register_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_register_Test, TG013_001);
    RUN_TEST_CASE(sci_init_register_Test, TG013_002);
    RUN_TEST_CASE(sci_init_register_Test, TG013_003);
    RUN_TEST_CASE(sci_init_register_Test, TG013_004);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_register_Test, TG013_001);
    RUN_TEST_CASE(sci_init_register_Test, TG013_002);
    RUN_TEST_CASE(sci_init_register_Test, TG013_003);
    RUN_TEST_CASE(sci_init_register_Test, TG013_004);
#endif
}

TEST_GROUP_RUNNER(sci_init_async_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_async_Test, TG014_001);
    RUN_TEST_CASE(sci_init_async_Test, TG014_002);
    RUN_TEST_CASE(sci_init_async_Test, TG014_003);
    RUN_TEST_CASE(sci_init_async_Test, TG014_004);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_async_Test, TG014_001);
    RUN_TEST_CASE(sci_init_async_Test, TG014_002);
    RUN_TEST_CASE(sci_init_async_Test, TG014_003);
    RUN_TEST_CASE(sci_init_async_Test, TG014_004);
#endif
}

TEST_GROUP_RUNNER(sci_init_sync_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_sync_Test, TG015_001);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_002);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_003);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_004);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_005);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_sync_Test, TG015_001);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_002);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_003);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_004);
    RUN_TEST_CASE(sci_init_sync_Test, TG015_005);
#endif
}

TEST_GROUP_RUNNER(sci_init_queues_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_queues_Test, TG016_001);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_002);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_003);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_004);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_005);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_006);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_007);
#if defined (BSP_MCU_RX65N) || defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_init_queues_Test, TG016_008);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_009);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_010);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_011);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_012);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_013);
#endif
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_queues_Test, TG016_001);
    RUN_TEST_CASE(sci_init_queues_Test, TG016_002);
#if !defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_queues_Test, TG016_003); //CH8 not available on RX13T
#endif
    RUN_TEST_CASE(sci_init_queues_Test, TG016_004);
#endif
}

TEST_GROUP_RUNNER(sci_initialize_ints_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_initialize_ints_Test, TG017_001);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_initialize_ints_Test, TG017_001);
#endif
}

TEST_GROUP_RUNNER(sci_init_bit_rate_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_bit_rate_Test, TG018_001);
    RUN_TEST_CASE(sci_init_bit_rate_Test, TG018_002);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_init_bit_rate_Test, TG018_001);
    RUN_TEST_CASE(sci_init_bit_rate_Test, TG018_002);
#endif
}

TEST_GROUP_RUNNER(sci_disable_ints_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_disable_ints_Test, TG019_001);
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_disable_ints_Test, TG019_001);
#endif
}

TEST_GROUP_RUNNER(sci_send_async_data_Test)
{
    RUN_TEST_CASE(sci_send_async_data_Test, TG020_001);
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_send_async_data_Test, TG020_002);
    RUN_TEST_CASE(sci_send_async_data_Test, TG020_003);
#endif
}

TEST_GROUP_RUNNER(sci_send_sync_data_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_send_sync_data_Test, TG021_001);
    RUN_TEST_CASE(sci_send_sync_data_Test, TG021_002);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_send_sync_data_Test, TG021_001);
    RUN_TEST_CASE(sci_send_sync_data_Test, TG021_002);
#endif
    RUN_TEST_CASE(sci_send_sync_data_Test, TG021_003);
}

TEST_GROUP_RUNNER(sci_receive_async_data_Test)
{
    RUN_TEST_CASE(sci_receive_async_data_Test, TG022_001);
    RUN_TEST_CASE(sci_receive_async_data_Test, TG022_002);
}

TEST_GROUP_RUNNER(sci_receive_sync_data_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_001);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_002);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_003);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_004);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_005);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_006);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_007);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_008);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_009);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_010);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_011);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_012);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_013);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_014);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_015);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_016);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_017);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_018);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_019);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_020);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_021);
#endif
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_001);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_002);
    RUN_TEST_CASE(sci_receive_sync_data_Test, TG023_003);
#endif
}

TEST_GROUP_RUNNER(sci_async_cmds_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_001);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_002);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_003);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_004);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_005);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_006);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_007);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_008);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_009);
#if (SCI_CFG_DATA_MATCH_INCLUDED == 1)
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_010);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_011);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_012);
#endif
#endif

#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_001);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_002);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_003);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_004);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_005);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_006);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_007);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_008);
    RUN_TEST_CASE(sci_async_cmds_Test, TG024_009);
#endif
}

TEST_GROUP_RUNNER(sci_sync_cmds_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_001);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_002);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_003);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_004);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_005);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_006);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_007);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_008);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_009);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_010);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_001);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_002);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_003);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_004);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_005);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_006);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_007);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_008);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_009);
    RUN_TEST_CASE(sci_sync_cmds_Test, TG025_010);
#endif
}

TEST_GROUP_RUNNER(tei_handler_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(tei_handler_Test, TG026_001);
    RUN_TEST_CASE(tei_handler_Test, TG026_002);
#endif
#if defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T)
    RUN_TEST_CASE(tei_handler_Test, TG026_001);
    RUN_TEST_CASE(tei_handler_Test, TG026_002);
#endif
}

TEST_GROUP_RUNNER(sci_fifo_transfer_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_001);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_002);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_003);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_004);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_005);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_006);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_007);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_008);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_009);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_010);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_011);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_012);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_013);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_014);
    RUN_TEST_CASE(sci_fifo_transfer_Test, TG027_015);
#endif
#endif
}

TEST_GROUP_RUNNER(sci_fifo_receive_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_001);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_002);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_003);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_004);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_005);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_006);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_007);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_008);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_009);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_010);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_011);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_012);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_013);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_014);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_015);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_016);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_017);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_018);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_019);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_020);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_021);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_022);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_023);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_024);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_025);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_026);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_027);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_028);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_029);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_030);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_031);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_032);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_033);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_034);
    RUN_TEST_CASE(sci_fifo_receive_Test, TG028_035);
#endif
#endif
}

TEST_GROUP_RUNNER(sci_fifo_receive_sync_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_001);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_002);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_003);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_004);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_005);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_006);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_007);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_008);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_009);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_010);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_011);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_012);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_013);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_014);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_015);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_016);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_017);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_018);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_019);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_020);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_021);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_022);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_023);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_024);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_025);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_026);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_027);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_028);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_029);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_030);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_031);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_032);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_033);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_034);
    RUN_TEST_CASE(sci_fifo_receive_sync_Test, TG029_035);
#endif
#endif
}

TEST_GROUP_RUNNER(sci_fifo_error_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_001);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_002);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_003);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_004);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_005);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_006);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_007);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_008);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_009);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_010);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_011);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_012);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_013);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_014);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_015);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_016);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_017);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_018);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_019);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_020);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_021);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_022);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_023);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_024);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_025);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_026);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_027);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_028);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_029);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_030);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_031);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_032);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_033);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_034);
    RUN_TEST_CASE(sci_fifo_error_Test, TG030_035);
#endif
#endif
}

TEST_GROUP_RUNNER(sci_init_fifo_Test)
{
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_001);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_002);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_003);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_004);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_005);
#if defined (BSP_MCU_RX72M)
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_006);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_007);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_008);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_009);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_010);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_011);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_012);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_013);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_014);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_015);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_016);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_017);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_018);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_019);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_020);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_021);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_022);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_023);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_024);
    RUN_TEST_CASE(sci_init_fifo_Test, TG031_025);
#endif
#endif
}

#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
#if (SCI_CFG_DATA_MATCH_INCLUDED == 1)
TEST_GROUP_RUNNER(sci_receive_data_match_Test)
{
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_001);
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_002);
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_003);
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_004);
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_005);
    RUN_TEST_CASE(sci_receive_data_match_Test, TG032_006);
}
#endif
#endif

/***********************************************************************************************************************
* Function Name: RunAllTests
* Description  : Call test groups
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
static void RunAllTests(void)
{
    /* Run each test group. */
    printf("RUN TEST GROUP: R_SCI_Open_Test\n");
    RUN_TEST_GROUP(R_SCI_Open_Test);
    printf("END TEST GROUP: R_SCI_Open_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_Close_Test\n");
    RUN_TEST_GROUP(R_SCI_Close_Test);
    printf("END TEST GROUP: R_SCI_Close_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_Send_Test\n");
    RUN_TEST_GROUP(R_SCI_Send_Test);
    printf("END TEST GROUP: R_SCI_Send_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_Receive_Test\n");
    RUN_TEST_GROUP(R_SCI_Receive_Test);
    printf("END TEST GROUP: R_SCI_Receive_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_SendReceive_Test\n");
    RUN_TEST_GROUP(R_SCI_SendReceive_Test);
    printf("END TEST GROUP: R_SCI_SendReceive_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_Control_Test\n");
    RUN_TEST_GROUP(R_SCI_Control_Test);
    printf("END TEST GROUP: R_SCI_Control_Test\n\n");

    printf("RUN TEST GROUP: R_SCI_GetVersion_Test\n");
    RUN_TEST_GROUP(R_SCI_GetVersion_Test);
    printf("END TEST GROUP: R_SCI_GetVersion_Test\n\n");

    printf("RUN TEST GROUP: txi_handler_Test\n");
    RUN_TEST_GROUP(txi_handler_Test);
    printf("END TEST GROUP: txi_handler_Test\n\n");

    printf("RUN TEST GROUP: rxi_handler_Test\n");
    RUN_TEST_GROUP(rxi_handler_Test);
    printf("END TEST GROUP: rxi_handler_Test\n\n");

    printf("RUN TEST GROUP: eri_handler_Test\n");
    RUN_TEST_GROUP(eri_handler_Test);
    printf("END TEST GROUP: eri_handler_Test\n\n");

    printf("RUN TEST GROUP: power_on_Test\n");
    RUN_TEST_GROUP(power_on_Test);
    printf("END TEST GROUP: power_on_Test\n\n");

    printf("RUN TEST GROUP: power_off_Test\n");
    RUN_TEST_GROUP(power_off_Test);
    printf("END TEST GROUP: power_off_Test\n\n");

    printf("RUN TEST GROUP: sci_init_register_Test\n");
    RUN_TEST_GROUP(sci_init_register_Test);
    printf("END TEST GROUP: sci_init_register_Test\n\n");

    printf("RUN TEST GROUP: sci_init_async_Test\n");
    RUN_TEST_GROUP(sci_init_async_Test);
    printf("END TEST GROUP: sci_init_async_Test\n\n");

    printf("RUN TEST GROUP: sci_init_sync_Test\n");
    RUN_TEST_GROUP(sci_init_sync_Test);
    printf("END TEST GROUP: sci_init_sync_Test\n\n");

    printf("RUN TEST GROUP: sci_init_queues_Test\n");
    RUN_TEST_GROUP(sci_init_queues_Test);
    printf("END TEST GROUP: sci_init_queues_Test\n\n");

    printf("RUN TEST GROUP: sci_initialize_ints_Test\n");
    RUN_TEST_GROUP(sci_initialize_ints_Test);
    printf("END TEST GROUP: sci_initialize_ints_Test\n\n");

    printf("RUN TEST GROUP: sci_init_bit_rate_Test\n");
    RUN_TEST_GROUP(sci_init_bit_rate_Test);
    printf("END TEST GROUP: sci_init_bit_rate_Test\n\n");

    printf("RUN TEST GROUP: sci_disable_ints_Test\n");
    RUN_TEST_GROUP(sci_disable_ints_Test);
    printf("END TEST GROUP: sci_disable_ints_Test\n\n");

    printf("RUN TEST GROUP: sci_send_async_data_Test\n");
    RUN_TEST_GROUP(sci_send_async_data_Test);
    printf("END TEST GROUP: sci_send_async_data_Test\n\n");

    printf("RUN TEST GROUP: sci_send_sync_data_Test\n");
    RUN_TEST_GROUP(sci_send_sync_data_Test);
    printf("END TEST GROUP: sci_send_sync_data_Test\n\n");

    printf("RUN TEST GROUP: sci_receive_async_data_Test\n");
    RUN_TEST_GROUP(sci_receive_async_data_Test);
    printf("END TEST GROUP: sci_receive_async_data_Test\n\n");

    printf("RUN TEST GROUP: sci_receive_sync_data_Test\n");
    RUN_TEST_GROUP(sci_receive_sync_data_Test);
    printf("END TEST GROUP: sci_receive_sync_data_Test\n\n");

    printf("RUN TEST GROUP: sci_async_cmds_Test\n");
    RUN_TEST_GROUP(sci_async_cmds_Test);
    printf("END TEST GROUP: sci_async_cmds_Test\n\n");

    printf("RUN TEST GROUP: sci_sync_cmds_Test\n");
    RUN_TEST_GROUP(sci_sync_cmds_Test);
    printf("END TEST GROUP: sci_sync_cmds_Test\n\n");

    printf("RUN TEST GROUP: tei_handler_Test\n");
    RUN_TEST_GROUP(tei_handler_Test);
    printf("END TEST GROUP: tei_handler_Test\n\n");
#if !(defined (BSP_MCU_RX23W) || defined (BSP_MCU_RX13T))
    printf("RUN TEST GROUP: sci_fifo_transfer_Test\n");
    RUN_TEST_GROUP(sci_fifo_transfer_Test);
    printf("END TEST GROUP: sci_fifo_transfer_Test\n\n");

    printf("RUN TEST GROUP: sci_fifo_receive_Test\n");
    RUN_TEST_GROUP(sci_fifo_receive_Test);
    printf("END TEST GROUP: sci_fifo_receive_Test\n\n");

    printf("RUN TEST GROUP: sci_fifo_receive_sync_Test\n");
    RUN_TEST_GROUP(sci_fifo_receive_sync_Test);
    printf("END TEST GROUP: sci_fifo_receive_sync_Test\n\n");

    printf("RUN TEST GROUP: sci_fifo_error_Test\n");
    RUN_TEST_GROUP(sci_fifo_error_Test);
    printf("END TEST GROUP: sci_fifo_error_Test\n\n");

    printf("RUN TEST GROUP: sci_init_fifo_Test\n");
    RUN_TEST_GROUP(sci_init_fifo_Test);
    printf("END TEST GROUP: sci_init_fifo_Test\n\n");

#if (SCI_CFG_DATA_MATCH_INCLUDED == 1)
    printf("RUN TEST GROUP: sci_receive_data_match_Test\n");
    RUN_TEST_GROUP(sci_receive_data_match_Test);
    printf("END TEST GROUP: sci_receive_data_match_Test\n\n");
#endif
#endif
}
/***********************************************************************************************************************
End of function RunAllTests
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/

void main()
{
    UnityMain(0, 0, RunAllTests);

    while(1)
    {
        /* Infinite loop. */
    }
}
/***********************************************************************************************************************
End of function main
***********************************************************************************************************************/
