/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name	   : test_cases.c
* Description  : Unity unit tests for RX IRQ module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 29.06.2018 1.00     First Release
*                               Added support RX65N, RX65N-2MB, RX66T-L, RX72T, RX72M
***********************************************************************************************************************/

/* Check the flag to enable test scripts for unit test */

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <test_stub.h>
#include "platform.h"
#include "r_irq_rx_if.h"
#include "r_irq_rx_config.h"
#include "unity_fixture.h"


/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
/* Declare test groups. */

TEST_GROUP(R_IRQ_Open_Test);

TEST_SETUP(R_IRQ_Open_Test)
{
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_Open_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_1
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_1)
{
	printf("TG001_1: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_MAX;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, NULL);

	TEST_ASSERT_EQUAL(IRQ_ERR_BAD_NUM, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_1
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_2
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_2)
{
	printf("TG001_2: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);

	TEST_ASSERT_EQUAL(IRQ_ERR_NOT_CLOSED, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_2
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_3
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_3)
{
	printf("TG001_3: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = (irq_trigger_t)(0xF3);
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);

	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_ARG, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_3
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_4
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_4)
{
	printf("TG001_4: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = (irq_prio_t)(16);
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, NULL);

	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_ARG, ret);

}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_4
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_5
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_5)
{
	printf("TG001_5: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, NULL, NULL);

	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);

}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_5
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_6
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_6)
{
	printf("TG001_6: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, NULL);

	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_6
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_7
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_7)
{
	printf("TG001_7: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, FIT_NO_FUNC);

	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_7
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_8
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_8)
{
	printf("TG001_8: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_IRQ0 + irq_number));
	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);

	TEST_ASSERT_EQUAL(IRQ_ERR_LOCK, ret);
	R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_IRQ0 + irq_number));

}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_8
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_9
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_9)
{
	printf("TG001_9: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_9
***********************************************************************************************************************/
/***********************************************************************************************************************
* Function Name: TG001_10
* Description  : Test IRQ API function R_IRQ_Open()
***********************************************************************************************************************/
TEST(R_IRQ_Open_Test, TG001_10)
{
	printf("TG001_10: Test R_IRQ_Open: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_1;
	irq_trigger_t    trigger = IRQ_TRIG_BOTH_EDGE;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Open_Test_TG001_10
***********************************************************************************************************************/

/* Declare test groups. */

TEST_GROUP(R_IRQ_Control_Test);

TEST_SETUP(R_IRQ_Control_Test)
{

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_Control_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_1
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_1)
{
	printf("TG002_1: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_cmd_t     cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    cmd_data = IRQ_PRI_0;

	/* Control IRQ */
	ret = R_IRQ_Control(NULL, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_1
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_2
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_2)
{
	printf("TG002_2: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, NULL);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_2
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_3
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_3)
{
	printf("TG002_3: Test R_IRQ_Control: ");

	irq_hdl_stuff_t temp;
	temp.irq_num = IRQ_NUM_MAX;
	temp.ien_bit_mask = 0x01;
	temp.ier_reg_index = 0x08;
	temp.filt_clk_div = 3;
	temp.filt_enable = 0;
	temp.pirq_callback = (void*)my_irq_callback;
	temp.pirq_in_port = (uint8_t *)PORT1.PIDR.BYTE;
	temp.irq_port_bit =  IRQ_BIT0;

	irq_err_t ret;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    	 cmd_data = IRQ_PRI_0;

	/* Control IRQ */
	ret = R_IRQ_Control((irq_handle_t)&temp, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_BAD_NUM, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_3
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_4
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_4)
{
	printf("TG002_4: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    	 cmd_data = IRQ_PRI_0;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);

	TEST_ASSERT_EQUAL(IRQ_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_4
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_5
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_5)
{
	printf("TG002_5: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_LIST_END;
	irq_prio_t    	 cmd_data = IRQ_PRI_0;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_UNKNOWN_CMD, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_5
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_6
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_6)
{
	printf("TG002_6: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    	 cmd_data = IRQ_PRI_0;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_IRQ0 + irq_number));

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_LOCK, ret);

	R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_IRQ0 + irq_number));

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_6
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_7
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_7)
{
	printf("TG002_7: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    	 cmd_data = IRQ_PRI_1;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_7
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_8
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_8)
{
	printf("TG002_8: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_PRIO;
	irq_prio_t    	 cmd_data = (irq_prio_t)(16);

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_ARG, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_8
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_9
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_9)
{
	printf("TG002_9: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_TRIG;
	irq_trigger_t    cmd_data = IRQ_TRIG_FALLING;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_9
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_10
* Description  : Test IRQ API function R_IRQ_Control()
***********************************************************************************************************************/
TEST(R_IRQ_Control_Test, TG002_10)
{
	printf("TG002_10: Test R_IRQ_Control: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	irq_cmd_t     	 cmd = IRQ_CMD_SET_TRIG;
	irq_trigger_t    cmd_data = (irq_trigger_t)(0xF3);

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	/* Control IRQ */
	ret = R_IRQ_Control(irq_handle, cmd, &cmd_data);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_ARG, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Control_Test_TG002_10
***********************************************************************************************************************/


/* Declare test groups. */

TEST_GROUP(R_IRQ_Close_Test);

TEST_SETUP(R_IRQ_Close_Test)
{
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_Close_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Close_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_1
* Description  : Test IRQ API function R_IRQ_Close()
***********************************************************************************************************************/
TEST(R_IRQ_Close_Test, TG003_1)
{
	printf("TG003_1: Test R_IRQ_Close: ");

	irq_err_t ret;

	ret = R_IRQ_Close(NULL);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Close_Test_TG003_1
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_2
* Description  : Test IRQ API function R_IRQ_Close()
***********************************************************************************************************************/
TEST(R_IRQ_Close_Test, TG003_2)
{
	printf("TG003_2: Test R_IRQ_Close: ");

	irq_hdl_stuff_t temp;
	temp.irq_num = IRQ_NUM_MAX;
	temp.ien_bit_mask = 0x01;
	temp.ier_reg_index = 0x08;
	temp.filt_clk_div = 3;
	temp.filt_enable = 0;
	temp.pirq_callback = (void*)my_irq_callback;
	temp.pirq_in_port = (uint8_t *)PORT1.PIDR.BYTE;
	temp.irq_port_bit =  IRQ_BIT0;

	irq_err_t ret;

	/* Control IRQ */
	ret = R_IRQ_Close((irq_handle_t)&temp);
	TEST_ASSERT_EQUAL(IRQ_ERR_BAD_NUM, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Close_Test_TG003_2
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_3
* Description  : Test IRQ API function R_IRQ_Close()
***********************************************************************************************************************/
TEST(R_IRQ_Close_Test, TG003_3)
{
	printf("TG003_3: Test R_IRQ_Close: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	R_IRQ_Close(irq_handle);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Close_Test_TG003_3
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_4
* Description  : Test IRQ API function R_IRQ_Close()
***********************************************************************************************************************/
TEST(R_IRQ_Close_Test, TG003_4)
{
	printf("TG003_4: Test R_IRQ_Close: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_Close_Test_TG003_4
***********************************************************************************************************************/


/* Declare test groups. */

TEST_GROUP(R_IRQ_ReadInput_Test);

TEST_SETUP(R_IRQ_ReadInput_Test)
{
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_ReadInput_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_1
* Description  : Test IRQ API function R_IRQ_ReadInput()
***********************************************************************************************************************/
TEST(R_IRQ_ReadInput_Test, TG004_1)
{
	printf("TG004_1: Test R_IRQ_ReadInput: ");

	irq_err_t       ret;
	uint8_t 		level;

	ret = R_IRQ_ReadInput(NULL, &level);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TG004_1
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_2
* Description  : Test IRQ API function R_IRQ_ReadInput()
***********************************************************************************************************************/
TEST(R_IRQ_ReadInput_Test, TG004_2)
{
	printf("TG004_2: Test R_IRQ_ReadInput: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_ReadInput(irq_handle, NULL);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);

	ret = R_IRQ_Close(irq_handle);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TG004_2
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_3
* Description  : Test IRQ API function R_IRQ_ReadInput()
***********************************************************************************************************************/
TEST(R_IRQ_ReadInput_Test, TG004_3)
{
	printf("TG004_3: Test R_IRQ_ReadInput: ");

	irq_hdl_stuff_t temp;
	temp.irq_num = IRQ_NUM_MAX;
	temp.ien_bit_mask = 0x01;
	temp.ier_reg_index = 0x08;
	temp.filt_clk_div = 3;
	temp.filt_enable = 0;
	temp.pirq_callback = (void*)my_irq_callback;
	temp.pirq_in_port = (uint8_t *)PORT1.PIDR.BYTE;
	temp.irq_port_bit =  IRQ_BIT0;

	irq_err_t ret;
	uint8_t level;

	ret = R_IRQ_ReadInput((irq_handle_t)&temp, &level);
	if(IRQ_ERR_BAD_NUM == ret)
	{
	    TEST_ASSERT_TRUE(true);
	}
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TG004_3
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_4
* Description  : Test IRQ API function R_IRQ_ReadInput()
***********************************************************************************************************************/
TEST(R_IRQ_ReadInput_Test, TG004_4)
{
	printf("TG004_4: Test R_IRQ_ReadInput: ");

	irq_err_t ret;
	irq_number_t     irq_number = IRQ_NUM_0;
	irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
	irq_prio_t       priority = IRQ_PRI_0;
	irq_handle_t     irq_handle;
	uint8_t          level;

	/* Open IRQ */
	ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	R_IRQ_Close(irq_handle);

	ret = R_IRQ_ReadInput(irq_handle, &level);
	TEST_ASSERT_EQUAL(IRQ_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TG004_4
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name: TG004_5
* Description  : Test IRQ API function R_IRQ_ReadInput()
***********************************************************************************************************************/
TEST(R_IRQ_ReadInput_Test, TG004_5)
{
	printf("TG004_5: Test R_IRQ_ReadInput: ");

	irq_err_t ret;
    irq_number_t     irq_number = IRQ_NUM_0;
    irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
    irq_prio_t       priority = IRQ_PRI_0;
    irq_handle_t     irq_handle;
    uint8_t          level;

    /* Open IRQ */
    ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

    ret = R_IRQ_ReadInput(irq_handle, &level);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);
    TEST_ASSERT_EQUAL((uint8_t)((*irq_handle->pirq_in_port) & irq_handle->irq_port_bit), level);

    R_IRQ_Close(irq_handle);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_ReadInput_Test_TG004_5
***********************************************************************************************************************/

/* Declare test groups. */

TEST_GROUP(R_IRQ_InterruptEnable_Test);

TEST_SETUP(R_IRQ_InterruptEnable_Test)
{
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_InterruptEnable_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_1
* Description  : Test IRQ API function R_IRQ_InterruptEnable()
***********************************************************************************************************************/
TEST(R_IRQ_InterruptEnable_Test, TG005_1)
{
	printf("TG005_1: Test R_IRQ_InterruptEnable: ");

	irq_err_t       ret;
	bool	 		enable = true;

	ret = R_IRQ_InterruptEnable(NULL, enable);
	TEST_ASSERT_EQUAL(IRQ_ERR_INVALID_PTR, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TG005_1
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_2
* Description  : Test IRQ API function R_IRQ_InterruptEnable()
***********************************************************************************************************************/
TEST(R_IRQ_InterruptEnable_Test, TG005_2)
{
	printf("TG005_2: Test R_IRQ_InterruptEnable: ");

	irq_hdl_stuff_t temp;
    temp.irq_num = IRQ_NUM_MAX;
    temp.ien_bit_mask = 0x01;
    temp.ier_reg_index = 0x08;
    temp.filt_clk_div = 3;
    temp.filt_enable = 0;
    temp.pirq_callback = (void*)my_irq_callback;
    temp.pirq_in_port = (uint8_t *)PORT1.PIDR.BYTE;
    temp.irq_port_bit =  IRQ_BIT0;

    irq_err_t ret;
    bool      enable = true;

	ret = R_IRQ_InterruptEnable((irq_handle_t)&temp, enable);
	TEST_ASSERT_EQUAL(IRQ_ERR_BAD_NUM, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TG005_2
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_3
* Description  : Test IRQ API function R_IRQ_InterruptEnable()
***********************************************************************************************************************/
TEST(R_IRQ_InterruptEnable_Test, TG005_3)
{
	printf("TG005_3: Test R_IRQ_InterruptEnable: ");

	irq_err_t        ret;
    irq_number_t     irq_number = IRQ_NUM_0;
    irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
    irq_prio_t       priority = IRQ_PRI_0;
    irq_handle_t     irq_handle;
    bool             enable = true;

    /* Open IRQ */
    ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

    R_IRQ_Close(irq_handle);

	ret = R_IRQ_InterruptEnable(irq_handle, enable);

	TEST_ASSERT_EQUAL(IRQ_ERR_NOT_OPENED, ret);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TG005_3
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_4
* Description  : Test IRQ API function R_IRQ_InterruptEnable()
***********************************************************************************************************************/
TEST(R_IRQ_InterruptEnable_Test, TG005_4)
{
	printf("TG005_4: Test R_IRQ_InterruptEnable: ");

	irq_err_t        ret;
    irq_number_t     irq_number = IRQ_NUM_0;
    irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
    irq_prio_t       priority = IRQ_PRI_0;
    irq_handle_t     irq_handle;
    bool             enable = true;

    /* Open IRQ */
    ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	ret = R_IRQ_InterruptEnable(irq_handle, enable);
	TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

	R_IRQ_Close(irq_handle);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TG005_4
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_5
* Description  : Test IRQ API function R_IRQ_InterruptEnable()
***********************************************************************************************************************/
TEST(R_IRQ_InterruptEnable_Test, TG005_5)
{
	printf("TG005_5: Test R_IRQ_InterruptEnable: ");

	irq_err_t        ret;
    irq_number_t     irq_number = IRQ_NUM_0;
    irq_trigger_t    trigger = IRQ_TRIG_LOWLEV;
    irq_prio_t       priority = IRQ_PRI_0;
    irq_handle_t     irq_handle;
    bool             enable = false;

    /* Open IRQ */
    ret = R_IRQ_Open(irq_number, trigger, priority, &irq_handle, my_irq_callback);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

    ret = R_IRQ_InterruptEnable(irq_handle, enable);
    TEST_ASSERT_EQUAL(IRQ_SUCCESS, ret);

    R_IRQ_Close(irq_handle);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_InterruptEnable_Test_TG005_5
***********************************************************************************************************************/

/* Declare test groups. */

TEST_GROUP(R_IRQ_GetVersion_Test);

TEST_SETUP(R_IRQ_GetVersion_Test)
{
}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_IRQ_GetVersion_Test)
{
	printf("-------------------------------------------\r\n");
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_GetVersion_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_1
* Description  : Test IRQ API function R_IRQ_GetVersion()
***********************************************************************************************************************/
TEST(R_IRQ_GetVersion_Test, TG006_1)
{
	printf("TG006_1: Test R_IRQ_GetVersion: ");

	uint32_t version_number;

	version_number = R_IRQ_GetVersion();
	printf("0x%x", version_number);

	TEST_ASSERT_EQUAL(0x0003001E, version_number);
}
/***********************************************************************************************************************
End of function TEST_R_IRQ_GetVersion_Test_TG006_1
***********************************************************************************************************************/
