
#ifndef TEST_TEST_STUFF_H_
#define TEST_TEST_STUFF_H_

#include "platform.h"
#include "r_irq_rx_if.h"
#include "r_irq_rx_private.h"

typedef struct
{
	irq_number_t  irq_num;
	uint8_t ien_bit_mask;    /* Bit mask for the interrupt enable register bit for this IRQ. */
	uint8_t ier_reg_index;   /* An index to the Interrupt enable register location for this interrupt. */
	uint8_t filt_clk_div;    /* PCLK divisor setting for the input pin digital filter. */
	uint8_t filt_enable;     /* Filter enable setting (on or off) for the input pin digital filter. */
	irq_callback * pirq_callback; /* pointer to callback function pointer. */
	uint8_t const *pirq_in_port;    /* Pointer to the I/O port input data register for this IRQ. */
	irq_8bit_mask_t irq_port_bit;  /* I/O port input data bit mask for this IRQ. */
} irq_hdl_stuff_t;

void my_irq_callback(void *pargs);

#endif /* TEST_TEST_STUFF_H_ */
