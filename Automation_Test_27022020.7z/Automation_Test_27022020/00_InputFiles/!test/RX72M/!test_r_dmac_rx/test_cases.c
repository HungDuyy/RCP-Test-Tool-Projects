/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_scripts_for_unittest.c
* Description  : Unity unit test for RX DMAC module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 07.12.2018 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "platform.h"
#include "r_dmaca_rx_config.h"
#include "r_dmaca_rx_if.h"
#include "r_dmaca_rx_private.h"

#include "../!test/unity/unity_fixture.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Imported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
/* Declare test groups. */
TEST_GROUP(R_DMACA_Open_Test);
TEST_GROUP(R_DMACA_Close_Test);
TEST_GROUP(R_DMACA_Create_Test);
TEST_GROUP(R_DMACA_Control_Test);
TEST_GROUP(R_DMACA_Init_Test);
TEST_GROUP(R_DMACA_Int_Callback_Test);
TEST_GROUP(R_DMACA_Int_Enable_Test);
TEST_GROUP(R_DMACA_Int_Disable_Test);
TEST_GROUP(R_DMACA_GetVersion_Test);
TEST_GROUP(r_dmaca_set_transfer_data_Test);
TEST_GROUP(r_dmaca_check_locking_sw_Test);
TEST_GROUP(r_dmaca_channel_valid_check_Test);
TEST_GROUP(r_dmaca_int_disable_Test);
TEST_GROUP(r_dmaca_int_enable_Test);
TEST_GROUP(r_dmaca_module_enable_Test);
TEST_GROUP(r_dmaca_module_disable_Test);
TEST_GROUP(r_dmaca_check_dtc_locking_byuser_Test);

/* Callback function for test */
void DMAC_callback_func(void *pArgs);

/*****************************************************************************
* Function Name: DMAC_callback_func
* Description  : This is a template for an DMAC Async Mode callback function.
* Arguments    : pArgs -
*                    pointer to DMAC_cb_args_t structure cast to a void. Structure
*                    contains event and associated data.
* Return Value : none
******************************************************************************/
void DMAC_callback_func(void *pArgs)
{

}
/***********************************************************************************************************************
* Function Name:R_DMACA_Open_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Open_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Open_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Open_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Open_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Open_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_001
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_001)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = 8;    /* Invalid channel */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_002
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_002)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Lock DMA channel */
    R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_DMAC0 + channel));

    /* Data for test */
    channel = DMACA_CH0;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_BUSY, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Release lock of DMA channel */
    R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_DMAC0 + channel));
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_003
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_003)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR0);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_004
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_004)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR1);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_005
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_005)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH2;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR2);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_006
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_006)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH3;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR3);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_007
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_007)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH4;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR4);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_008
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_008)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH5;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR5);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_009
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_009)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH6;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR6);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_010
* Description  : Test API function R_DMACA_Open()
***********************************************************************************************************************/
TEST(R_DMACA_Open_Test, TG001_010)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH7;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR7);
    TEST_ASSERT_EQUAL_INT32(0x00, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_OpenTest_TG001_010
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Close_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Close_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Close_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Close_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Close_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Close_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_001
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_001)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = 8;    /* Invalid channel */

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_002
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_002)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR0);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_003
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_003)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR1);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_004
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_004)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH2;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR2);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_005)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH3;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR3);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_006
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_006)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH4;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR4);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_007
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_007)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH5;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR5);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_008
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_008)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH6;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR6);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_009
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_009)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH7;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR7);
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_010
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_010)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

#if DMACA_CFG_USE_DTC_FIT_MODULE == 0
    TEST_IGNORE_MESSAGE("Please set DMACA_CFG_USE_DTC_FIT_MODULE to 1 and try again.");
#endif

    /* Lock DTC */
    R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_DTC));

    /* Data for test */
    channel = DMACA_CH7;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR7);
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS_DTC_BUSY, retCode);

    /* Release lock of DTC */
    R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_DTC));
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_011
* Description  : Test API function R_DMACA_Close()
***********************************************************************************************************************/
TEST(R_DMACA_Close_Test, TG002_011)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Open DMA channel 0 */
    retCode = R_DMACA_Open(DMACA_CH0);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Data for test */
    channel = DMACA_CH7;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, ICU.DMRSR7);
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS_OTHER_CH_BUSY, retCode);

    /* Close DMA channel 0 */
    retCode = R_DMACA_Close(DMACA_CH0);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CloseTest_TG002_011
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Create_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Create_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Create_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Create_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Create_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Create_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_001
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_001)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = 8;    /* Invalid channel */
    p_data_cfg = &data_cfg;

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_002)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = NULL;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_NULL_PTR, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_003)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x10000000);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_004
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_004)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_005
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_005)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_006
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_006)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH2;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_007
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_007)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH3;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_008
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_008)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH4;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_009
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_009)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH5;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_010
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_010)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH6;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_011
* Description  : Test API function R_DMACA_Create()
***********************************************************************************************************************/
TEST(R_DMACA_Create_Test, TG003_011)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    /* Data for test */
    channel = DMACA_CH7;
    p_data_cfg = &data_cfg;

    /* Set data configuration for DMA */
    data_cfg.p_src_addr = (void *)(0x00000001);
    data_cfg.p_des_addr = (void *)(0x00000002);
    data_cfg.src_addr_mode = DMACA_SRC_ADDR_FIXED;
    data_cfg.des_addr_mode = DMACA_DES_ADDR_FIXED;
    data_cfg.transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    data_cfg.transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    data_cfg.request_source =  DMACA_TRANSFER_REQUEST_SOFTWARE;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_CreateTest_TG003_011
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Control_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Control_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Control_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Control_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Control_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Control_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_001
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = 8;    /* Invalid channel */
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_002
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = (dmaca_command_t)(DMACA_CMD_DTIF_STATUS_CLR + 1);     /* Invalid DMA command */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_COMMAND, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_003
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = NULL;                 /* Invalid DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_NULL_PTR, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_004
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_005
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH1;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_006
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH2;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_007
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH3;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_008
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH4;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_009
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH5;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_010
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_010)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH6;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_011
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_011)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH7;
    command = DMACA_CMD_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_012
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_012)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_013
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_013)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH1;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_014
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_014)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH2;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_015
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_015)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH3;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_016
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_016)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH4;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_017
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_017)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH5;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_018
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_018)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH6;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_019
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_019)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH7;
    command = DMACA_CMD_RESUME;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_ENABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_019
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_020
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_020)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_020
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_021
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_021)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH1;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_021
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_022
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_022)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH2;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_022
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_023
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_023)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH3;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_023
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_024
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_024)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH4;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_024
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_025
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_025)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH5;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_025
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_026
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_026)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH6;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_026
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_027
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_027)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH7;
    command = DMACA_CMD_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_027
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_028
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_028)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_ALL_ENABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_ENABLE, DMACA_DMAST);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_028
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_029
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_029)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_ALL_DISABLE;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ACTIVE_DISABLE, DMACA_DMAST);

    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_029
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_030
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_030)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_030
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_031
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_031)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_031
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_032
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_032)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_032
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_033
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_033)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_033
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_034
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_034)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_034
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_035
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_035)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_035
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_036
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_036)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_036
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_037
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_037)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_037
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_038
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_038)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH0) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_038
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_039
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_039)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH1) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_039
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_040
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_040)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH2) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_040
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_041
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_041)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH3) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_041
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_042
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_042)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH4) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_042
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_043
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_043)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH5) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_043
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_044
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_044)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH6) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_044
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_045
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_045)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_REQ_BIT_MASK;
    DMACA_DMREQ(DMACA_CH7) |= DMACA_CLRS_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_045
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_046
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_046)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH0) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH0) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_046
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_047
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_047)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH1) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH1) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_047
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_048
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_048)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH2) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH2) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_048
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_049
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_049)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH3) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH3) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_049
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_050
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_050)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH4) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH4) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_050
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_051
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_051)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH5) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH5) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_051
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_052
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_052)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH6) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH6) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_052
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_053
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_053)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH7) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH7) |= DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUESTED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_053
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_054
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_054)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH0) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH0) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_054
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_055
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_055)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH1) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH1) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_055
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_056
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_056)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH2) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH2) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_056
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_057
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_057)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH3) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH3) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_057
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_058
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_058)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH4) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH4) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_058
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_059
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_059)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH5) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH5) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_059
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_060
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_060)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH6) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH6) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_060
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_061
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_061)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH7) &= ~DMACA_CLRS_BIT_MASK;
    DMACA_DMREQ(DMACA_CH7) &= ~DMACA_SWREQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_WITH_AUTO_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_WITH_AUTO_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_061
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_062
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_062)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_062
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_063
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_063)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_063
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_064
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_064)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_064
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_065
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_065)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_065
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_066
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_066)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_066
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_067
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_067)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_067
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_068
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_068)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_068
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_069
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_069)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_069
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_070
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_070)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_070
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_071
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_071)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_071
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_072
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_072)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_072
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_073
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_073)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_073
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_074
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_074)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_074
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_075
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_075)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_075
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_076
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_076)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_076
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_077
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_077)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_NOT_CLR_REQ;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SOFT_REQ_NOT_CLR_REQ, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_077
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_078
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_078)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_078
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_079
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_079)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_079
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_080
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_080)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_080
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_081
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_081)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_081
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_082
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_082)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_082
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_083
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_083)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_083
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_084
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_084)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_084
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_085
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_085)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) |= DMACA_REQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_SOFTWARE_REQUEST_DISABLED, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_085
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_086
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_086)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH0;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_086
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_087
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_087)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH1;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_087
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_088
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_088)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH2;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_088
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_089
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_089)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH3;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_089
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_090
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_090)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH4;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_090
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_091
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_091)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH5;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_091
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_092
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_092)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH6;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_092
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_093
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_093)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_REQ_BIT_MASK;
    channel = DMACA_CH7;
    command = DMACA_CMD_SOFT_REQ_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_DMREQ(channel) & (~DMACA_SWREQ_BIT_MASK), DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_093
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_094
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_094)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    channel = DMACA_CH0;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_094
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_095
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_095)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    channel = DMACA_CH1;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_095
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_096
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_096)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH2;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_096
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_097
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_097)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH3;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_097
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_098
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_098)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH4;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_098
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_099
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_099)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH5;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_099
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_100
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_100)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH6;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_100
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_101
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_101)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH7;
    command = DMACA_CMD_ESIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_ESIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_101
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_102
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_102)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH0;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_102
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_103
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_103)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH1;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_103
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_104
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_104)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH2;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_104
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_105
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_105)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH3;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_105
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_106
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_106)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH4;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_106
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_107
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_107)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH5;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_107
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_108
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_108)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH6;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_108
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_109
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_109)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    channel = DMACA_CH7;
    command = DMACA_CMD_DTIF_STATUS_CLR;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL_UINT8(~((uint8_t)DMACA_DTIF_BIT_MASK), DMACA_DMSTS(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_109
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_110
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_110)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH0) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH0) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH0;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_110
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_111
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_111)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH1) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH1) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH1;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_111
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_112
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_112)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH2) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH2) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH2;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_112
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_113
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_113)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH3) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH3) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH3;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_113
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_114
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_114)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH4) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH4) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH4;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_114
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_115
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_115)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH5) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH5) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH5;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_115
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_116
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_116)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH6) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH6) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH6;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_116
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_117
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_117)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH7) &= ~DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) &= ~DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) &= ~DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) &= ~DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH7) |= DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH7;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(false, pState->act_stat);
    TEST_ASSERT_EQUAL(false, pState->dtif_stat);
    TEST_ASSERT_EQUAL(false, pState->esif_stat);
    TEST_ASSERT_EQUAL(false, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((uint32_t)DMACA_DMCRB(channel), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_117
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_118
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_118)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH0) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH0) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH0) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH0;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_118
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_119
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_119)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH1) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH1) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH1) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH1;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_119
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_120
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_120)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH2) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH2) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH2) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH2;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_120
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_121
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_121)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH3) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH3) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH3) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH3;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_121
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_122
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_122)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH4) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH4) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH4) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH4;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_122
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_123
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_123)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH5) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH5) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH5) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH5;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_123
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_124
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_124)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH6) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH6) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH6) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH6;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_124
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG004_125
* Description  : Test API function R_DMACA_Control()
***********************************************************************************************************************/
TEST(R_DMACA_Control_Test, TG004_125)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    dmaca_stat_t*       pState;     /* DMA state pointer */
    dmaca_command_t     command;    /* DMA command */

    /* DMA State for test */
    dmaca_stat_t        State = {
           false,       /* Software Request Status */
           false,       /* Transfer Escape End Interrupt Status */
           false,       /* Transfer End Interrupt Status */
           false,       /* Transfer Count */
           0            /* Active Flag of DMAC */
    };

    /* Data for test */
    DMACA_DMREQ(DMACA_CH7) |= DMACA_SWREQ_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) |= DMACA_ACT_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) |= DMACA_DTIF_BIT_MASK;
    DMACA_DMSTS(DMACA_CH7) |= DMACA_ESIF_BIT_MASK;
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_TRANSFER_MODE_REPEAT;
    DMACA_DMTMD(DMACA_CH7) &= ~DMACA_TRANSFER_MODE_BLOCK;
    channel = DMACA_CH7;
    command = DMACA_CMD_STATUS_GET;     /* DMA command     */
    pState  = &State;               /* DMA State       */

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Control DMA channel */
    retCode = R_DMACA_Control(channel, command, pState);

    /* Check result */
    TEST_ASSERT_EQUAL(true, pState->act_stat);
    TEST_ASSERT_EQUAL(true, pState->dtif_stat);
    TEST_ASSERT_EQUAL(true, pState->esif_stat);
    TEST_ASSERT_EQUAL(true, pState->soft_req_stat);
    TEST_ASSERT_EQUAL_UINT32((DMACA_INVALID_LOWER_BIT_MASK & DMACA_DMCRA(channel)), pState->transfer_count);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_ControlTest_TG004_125
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Init_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Init_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Init_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Init_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Init_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Init_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG005_001
* Description  : Test API function R_DMACA_Init()
***********************************************************************************************************************/
TEST(R_DMACA_Init_Test, TG005_001)
{
    /* Initialize a callback function array for DMACmI interrupt */
    R_DMACA_Init();

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[0]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[1]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[2]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[3]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[4]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[5]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[6]);
    TEST_ASSERT_EQUAL_INT32(FIT_NO_FUNC, g_pdmaci_handlers[7]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[0]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[1]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[2]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[3]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[4]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[5]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[6]);
    TEST_ASSERT_EQUAL_INT32(0, g_locking_sw[7]);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_InitTest_TG005_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Int_Callback_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Int_Callback_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Callback_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Int_Callback_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Int_Callback_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Callback_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_001
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = 8;    /* Invalid channel */
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_002
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH0;
    p_callback = NULL;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_HANDLER_ADDR, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_003
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH0;
    p_callback = FIT_NO_FUNC;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_HANDLER_ADDR, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_004
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH0;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_005
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH1;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_006
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH2;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_007
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH3;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_008
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH4;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_009
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH5;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_010
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_010)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH6;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG006_011
* Description  : Test API function R_DMACA_Int_Callback()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Callback_Test, TG006_011)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    void *              p_callback; /* Callback function */

    /* Data for test */
    channel = DMACA_CH7;
    p_callback = &DMAC_callback_func;

    /* Register a callback function for DMACmI interrupts. */
    retCode = R_DMACA_Int_Callback(channel, p_callback);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32((void*)&DMAC_callback_func, g_pdmaci_handlers[channel]);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_CallbackTest_TG006_011
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Int_Enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Int_Enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Int_Enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Int_Enable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_001
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = 8;    /* Invalid channel */
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_002
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH0;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_003
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH1;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_004
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH2;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_005
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH3;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_006
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH4;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_007
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH5;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_008
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH6;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG007_009
* Description  : Test API function R_DMACA_Int_Enable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Enable_Test, TG007_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH7;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = R_DMACA_Int_Enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_EnableTest_TG007_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_Int_Disable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_Int_Disable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Disable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_Int_Disable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_Int_Disable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_Int_Disable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_001
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = 8;    /* Invalid channel */

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_002
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_003
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH1;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_004
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH2;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_005
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH3;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_006
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH4;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_007
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH5;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_008
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH6;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG008_009
* Description  : Test API function R_DMACA_Int_Disable()
***********************************************************************************************************************/
TEST(R_DMACA_Int_Disable_Test, TG008_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH7;

    /* Disable DMACmI interrupt */
    retCode = R_DMACA_Int_Disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_Int_DisableTest_TG008_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:R_DMACA_GetVersion_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(R_DMACA_GetVersion_Test)
{

}
/***********************************************************************************************************************
End of function TEST_R_DMACA_GetVersion_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_R_DMACA_GetVersion_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_DMACA_GetVersion_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_R_DMACA_GetVersion_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG009_001
* Description  : Test API function R_DMACA_GetVersion()
***********************************************************************************************************************/
TEST(R_DMACA_GetVersion_Test, TG009_001)
{
    uint32_t version; /* DMA version */

    /* Get version of DMA */
    version = R_DMACA_GetVersion();

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00020014, version);
}
/***********************************************************************************************************************
* End of function TEST_R_DMACA_GetVersionTest_TG009_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_set_transfer_data_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_set_transfer_data_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_set_transfer_data_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_set_transfer_data_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_set_transfer_data_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_set_transfer_data_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_001
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_001)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x10000000;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_002
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_002)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x10000000;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_003
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_003)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_OFFSET;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->offset_value = 0x10000000;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_004
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_004)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_OFFSET;
    p_data_cfg->offset_value = 0x10000000;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_005
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_005)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_OFFSET;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_OFFSET;
    p_data_cfg->offset_value = 0x10000000;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_006
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_006)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_OFFSET;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_007
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_007)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_OFFSET;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_008
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_008)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_OFFSET;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_OFFSET;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_009
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_009)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A + 1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_009
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_010
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_010)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_REPEAT;
    p_data_cfg->transfer_count = DMACA_MIN_COUNT_VAL - 1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_010
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_011
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_011)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B  + 1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_011
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_012
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_012)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MIN_COUNT_VAL - 1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_012
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_013
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_013)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MAX_10BITS_COUNT_VAL + 1;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_013
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_014
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_014)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MAX_10BITS_COUNT_VAL;
    p_data_cfg->repeat_block_side = DMACA_REPEAT_BLOCK_SOURCE;
    p_data_cfg->src_addr_repeat_area = DMACA_SRC_ADDR_EXT_REP_AREA_2B;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_014
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_015
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_015)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MAX_10BITS_COUNT_VAL;
    p_data_cfg->repeat_block_side = DMACA_REPEAT_BLOCK_DESTINATION;
    p_data_cfg->src_addr_repeat_area = DMACA_SRC_ADDR_EXT_REP_AREA_2B;
    p_data_cfg->des_addr_repeat_area = DMACA_DES_ADDR_EXT_REP_AREA_2B;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_015
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_016
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_016)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    uint32_t                   valueDMAMD; /* Setting value of DMAMD */
    uint32_t                   valueDMTMD; /* Setting value of DMTMD */
    uint32_t                   valueDMCRA; /* Setting value of DMCRA */
    uint32_t                   valueDMINT; /* Setting value of DMINT */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MAX_10BITS_COUNT_VAL;
    p_data_cfg->repeat_block_side = DMACA_REPEAT_BLOCK_DESTINATION;
    p_data_cfg->src_addr_repeat_area = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    p_data_cfg->des_addr_repeat_area = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    p_data_cfg->request_source = DMACA_TRANSFER_REQUEST_PERIPHERAL;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Get value setting */
    valueDMAMD = p_data_cfg->src_addr_mode | p_data_cfg->src_addr_repeat_area | p_data_cfg->des_addr_mode | p_data_cfg->des_addr_repeat_area;
    valueDMTMD = p_data_cfg->transfer_mode | p_data_cfg->repeat_block_side | p_data_cfg->data_size | p_data_cfg->request_source;
    valueDMCRA = (p_data_cfg->block_size << 16) | p_data_cfg->block_size;
    valueDMINT = p_data_cfg->dtie_request | p_data_cfg->esie_request | p_data_cfg->rptie_request | p_data_cfg->sarie_request | p_data_cfg->darie_request;

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0x00, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->act_source, ICU_DMRSR(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMAMD, DMACA_DMAMD(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMTMD, DMACA_DMTMD(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->p_src_addr, DMACA_DMSAR(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->p_des_addr, DMACA_DMDAR(channel));
    TEST_ASSERT_EQUAL_INT32((uint32_t)((p_data_cfg->block_size << 16) | p_data_cfg->block_size), DMACA_DMCRA(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMCRA, DMACA_DMCRA(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->transfer_count, DMACA_DMCRB(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->interrupt_sel, DMACA_DMCSL(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMINT, DMACA_DMINT(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_016
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_017
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_017)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

    uint32_t                   valueDMAMD; /* Setting value of DMAMD */
    uint32_t                   valueDMTMD; /* Setting value of DMTMD */
    uint32_t                   valueDMINT; /* Setting value of DMINT */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_NORMAL;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    p_data_cfg->block_size = DMACA_MAX_10BITS_COUNT_VAL;
    p_data_cfg->repeat_block_side = DMACA_REPEAT_BLOCK_DESTINATION;
    p_data_cfg->src_addr_repeat_area = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    p_data_cfg->request_source = DMACA_TRANSFER_REQUEST_PERIPHERAL;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Get value setting */
    valueDMAMD = p_data_cfg->src_addr_mode | p_data_cfg->src_addr_repeat_area | p_data_cfg->des_addr_mode | p_data_cfg->des_addr_repeat_area;
    valueDMTMD = p_data_cfg->transfer_mode | p_data_cfg->repeat_block_side | p_data_cfg->data_size | p_data_cfg->request_source;
    valueDMINT = p_data_cfg->dtie_request | p_data_cfg->esie_request | p_data_cfg->rptie_request | p_data_cfg->sarie_request | p_data_cfg->darie_request;

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
    TEST_ASSERT_EQUAL_INT32(0x00, DMACA_DMREQ(channel));
    TEST_ASSERT_EQUAL_INT32(DMACA_TRANSFER_DISABLE, DMACA_DMCNT(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->act_source, ICU_DMRSR(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMAMD, DMACA_DMAMD(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMTMD, DMACA_DMTMD(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->p_src_addr, DMACA_DMSAR(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->p_des_addr, DMACA_DMDAR(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->transfer_count, DMACA_DMCRA(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->offset_value, DMACA_DMCRB(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->interrupt_sel, DMACA_DMCSL(channel));
    TEST_ASSERT_EQUAL_INT32(valueDMINT, DMACA_DMINT(channel));


}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_017
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_018
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_018)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH0;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_OFFSET;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_OFFSET;
    p_data_cfg->offset_value = 0x00FFFFFF;
    p_data_cfg->transfer_mode = DMACA_TRANSFER_MODE_BLOCK;
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_A;
    p_data_cfg->block_size = DMACA_MIN_COUNT_VAL;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
    TEST_ASSERT_EQUAL_INT32((uint32_t)((p_data_cfg->block_size << 16) | p_data_cfg->block_size), DMACA_DMCRA(channel));
    TEST_ASSERT_EQUAL_INT32(p_data_cfg->transfer_count, DMACA_DMCRB(channel));
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_018
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG010_019
* Description  : Test API function r_dmaca_set_transfer_data()
***********************************************************************************************************************/
TEST(r_dmaca_set_transfer_data_Test, TG010_019)
{
    dmaca_return_t             retCode;    /* Return code */
    uint8_t                    channel;    /* DMA channel */
    dmaca_transfer_data_cfg_t *p_data_cfg; /* Data configuration pointer */
    dmaca_transfer_data_cfg_t  data_cfg;   /* Data configuration */

   /* Data configuration */
    data_cfg.transfer_mode         = DMACA_TRANSFER_MODE_BLOCK;
    data_cfg.repeat_block_side     = DMACA_REPEAT_BLOCK_DISABLE;
    data_cfg.data_size             = DMACA_DATA_SIZE_LWORD;
    data_cfg.act_source            = IR_DMAC_DMAC0I;
    data_cfg.request_source        = DMACA_TRANSFER_REQUEST_SOFTWARE;
    data_cfg.dtie_request          = DMACA_TRANSFER_END_INTERRUPT_ENABLE;
    data_cfg.esie_request          = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_ENABLE;
    data_cfg.rptie_request         = DMACA_REPEAT_SIZE_END_INTERRUPT_ENABLE;
    data_cfg.sarie_request         = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.darie_request         = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    data_cfg.src_addr_mode         = DMACA_SRC_ADDR_INCR;
    data_cfg.src_addr_repeat_area  = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    data_cfg.des_addr_mode         = DMACA_DES_ADDR_INCR;
    data_cfg.des_addr_repeat_area  = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    data_cfg.offset_value          = 0;
    data_cfg.interrupt_sel         = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    data_cfg.transfer_count        = 16;
    data_cfg.block_size            = 16;

    /* Data for test */
    channel = DMACA_CH1;
    p_data_cfg = &data_cfg;

    /* Set data configuration for test */
    p_data_cfg->p_src_addr = (void*)0x00000000;
    p_data_cfg->p_des_addr = (void*)0x00000000;
    p_data_cfg->src_addr_mode = DMACA_SRC_ADDR_FIXED;
    p_data_cfg->des_addr_mode = DMACA_DES_ADDR_FIXED;
    p_data_cfg->transfer_mode = (dmaca_transfer_mode_t)(DMACA_TRANSFER_MODE_NORMAL+3);
    p_data_cfg->transfer_count = DMACA_MAX_16BITS_COUNT_VAL_B;
    p_data_cfg->block_size = DMACA_MIN_COUNT_VAL;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Set registers of the specified channel and the interrupt source */
    retCode = R_DMACA_Create(channel, p_data_cfg);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_ARG, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_set_transfer_dataTest_TG010_019
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_check_locking_sw_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_check_locking_sw_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_check_locking_sw_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_check_locking_sw_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_check_locking_sw_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_check_locking_sw_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG011_001
* Description  : Test API function r_dmaca_check_locking_sw()
***********************************************************************************************************************/
TEST(r_dmaca_check_locking_sw_Test, TG011_001)
{
    dmaca_return_t  retCode; /* Return code */
    uint8_t         channel; /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Open DMA channel */
    retCode = R_DMACA_Open(channel);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel */
    retCode = R_DMACA_Close(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_check_locking_swTest_TG011_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG011_002
* Description  : Test API function r_dmaca_check_locking_sw()
***********************************************************************************************************************/
TEST(r_dmaca_check_locking_sw_Test, TG011_002)
{
    dmaca_return_t  retCode;  /* Return code   */
    uint8_t         channel0; /* DMA channel 0 */
    uint8_t         channel1; /* DMA channel 1 */

    /* Data for test */
    channel0 = DMACA_CH0;
    channel1 = DMACA_CH1;

    /* Open DMA channel 0 */
    retCode = R_DMACA_Open(channel0);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Open DMA channel 1 */
    retCode = R_DMACA_Open(channel1);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);

    /* Close DMA channel 0 */
    retCode = R_DMACA_Close(channel0);
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS_OTHER_CH_BUSY, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_check_locking_swTest_TG011_002
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_channel_valid_check_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_channel_valid_check_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_channel_valid_check_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_channel_valid_check_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_channel_valid_check_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_channel_valid_check_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_001
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_001)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = 8;    /* Invalid channel */

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(false, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_002
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_002)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_003
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_003)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH1;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_004
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_004)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH2;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_005
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_005)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH3;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_006
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_006)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH4;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_007
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_007)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH5;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_008
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_008)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH6;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);

    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG012_009
* Description  : Test API function r_dmaca_channel_valid_check()
***********************************************************************************************************************/
TEST(r_dmaca_channel_valid_check_Test, TG012_009)
{
    bool    retValue;   /* Return value */
    uint8_t channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH7;

    /* Check valid DMA channel */
    retValue = r_dmaca_channel_valid_check(channel);
    /* Check result */
    TEST_ASSERT_EQUAL(true, retValue);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_channel_valid_checkTest_TG012_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_int_disable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_int_disable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_int_disable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_int_disable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_int_disable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_int_disable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_001
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = 8;    /* Invalid channel */

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_002
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH0;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_003
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH1;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_004
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH2;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_005
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH3;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_006
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH4;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_007
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH5;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_008
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH6;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG013_009
* Description  : Test API function r_dmaca_int_disable()
***********************************************************************************************************************/
TEST(r_dmaca_int_disable_Test, TG013_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */

    /* Data for test */
    channel = DMACA_CH7;

    /* Disable DMACmI interrupt */
    retCode = r_dmaca_int_disable(channel);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(0, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_disableTest_TG013_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_int_enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_int_enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_int_enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_int_enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_int_enable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_int_enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_001
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_001)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = 8;    /* Invalid channel */
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ERR_INVALID_CH, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_001
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_002
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_002)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH0;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC0I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_002
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_003
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_003)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH1;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC1I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_003
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_004
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_004)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH2;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC2I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_004
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_005
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_005)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH3;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC3I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_005
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_006
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_006)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH4;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_006
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_007
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_007)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH5;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_007
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_008
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_008)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH6;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_008
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG014_009
* Description  : Test API function r_dmaca_int_enable()
***********************************************************************************************************************/
TEST(r_dmaca_int_enable_Test, TG014_009)
{
    dmaca_return_t      retCode;    /* Return code */
    uint8_t             channel;    /* DMA channel */
    uint8_t             priority;     /* Interrupt priority level */

    /* Data for test */
    channel = DMACA_CH7;
    priority = 8;

    /* Enables DMACmI interrupt */
    retCode = r_dmaca_int_enable(channel, priority);

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(8, IPR(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(1, IEN(DMAC, DMAC74I));
    TEST_ASSERT_EQUAL_INT32(DMACA_SUCCESS, retCode);
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_int_enableTest_TG014_009
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_module_enable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_module_enable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_module_enable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_module_enable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_module_enable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_module_enable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG015_001
* Description  : Test API function r_dmaca_module_enable()
***********************************************************************************************************************/
TEST(r_dmaca_module_enable_Test, TG015_001)
{
    /* Enable DMA module. */
    r_dmaca_module_enable();

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(0, MSTP(DMAC));
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_module_enableTest_TG015_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_module_disable_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_module_disable_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_module_disable_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_module_disable_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_module_disable_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_module_disable_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG016_001
* Description  : Test API function r_dmaca_module_disable()
***********************************************************************************************************************/
TEST(r_dmaca_module_disable_Test, TG016_001)
{
    /* Disable DMA module. */
    r_dmaca_module_disable();

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(1, MSTP(DMAC));
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_module_disableTest_TG016_001
***********************************************************************************************************************/


/***********************************************************************************************************************
* Function Name:r_dmaca_check_dtc_locking_byuser_Test
* Description  :
***********************************************************************************************************************/
TEST_SETUP(r_dmaca_check_dtc_locking_byuser_Test)
{

}
/***********************************************************************************************************************
End of function TEST_r_dmaca_check_dtc_locking_byuser_Test_SETUP
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_r_dmaca_check_dtc_locking_byuser_Test_TEAR_DOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(r_dmaca_check_dtc_locking_byuser_Test)
{
    uint8_t nChannel = 0; /* DMA channel */

    /* Close all channels to ensure that they were closed before starting next case */
    for(nChannel = DMACA_CH0; nChannel <= DMACA_CH7; nChannel++)
    {
        R_DMACA_Close(nChannel);
    }
}
/***********************************************************************************************************************
End of function TEST_r_dmaca_check_dtc_locking_byuser_Test_TEAR_DOWN
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG017_001
* Description  : Test API function r_dmaca_check_dtc_locking_byuser()
***********************************************************************************************************************/
TEST(r_dmaca_check_dtc_locking_byuser_Test, TG017_001)
{
#if DMACA_CFG_USE_DTC_FIT_MODULE == 0
    dmaca_chk_locking_sw_t retCode; /* Return code */

    /* Checks DTC locking by user. */
    retCode = r_dmaca_check_dtc_locking_byuser();

    /* Check result */
    TEST_ASSERT_EQUAL_INT32(DMACA_ALL_CH_UNLOCKED_AND_DTC_UNLOCKED, retCode);

#else
    TEST_IGNORE_MESSAGE("Please set DMACA_CFG_USE_DTC_FIT_MODULE to 0 and try again.");
#endif
}
/***********************************************************************************************************************
* End of function TEST_r_dmaca_check_dtc_locking_byuserTest_TG017_001
***********************************************************************************************************************/

