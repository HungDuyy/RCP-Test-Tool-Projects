#include "platform.h"
#include "r_cmtw_rx_if.h"
#include "r_cmtw_rx_config.h"
#include "r_cmtw_rx_private.h"
#include "unity_fixture.h"
#include <stdio.h>


extern cmtw_prv_ch_ctrl_info_t * const g_cmtw_handles[];

TEST_GROUP(CMTW_UNITTEST);

TEST_SETUP(CMTW_UNITTEST)
{

}

TEST_TEAR_DOWN(CMTW_UNITTEST)
{

}

static void callback(void* pdata)
{
	R_BSP_NOP();
}

/*****************************
 * R_CMTW_Open() test cases
 * TG001_001 -> TG001_029
 ******************************/

TEST(CMTW_UNITTEST, TG001_001)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_MAX;

    err = R_CMTW_Open(channel, NULL, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_BAD_CHAN, err);
}

TEST(CMTW_UNITTEST, TG001_002)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;

    err = R_CMTW_Open(channel, NULL, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_003)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t *pconfig;
//  (void*)pconfig = FIT_NO_FUNC;
    pconfig =(cmtw_channel_settings_t *) FIT_NO_FUNC;

    err = R_CMTW_Open(channel, pconfig, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_004)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_MAX;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_005)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_MAX;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_006)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_MAX;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_007)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = (cmtw_clear_source_t)2;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_008)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = (cmtw_clear_source_t)3;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_009)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_CALLBACK;

    err = R_CMTW_Open(channel, &config, NULL);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_010)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_CALLBACK;

    err = R_CMTW_Open(channel, &config, FIT_NO_FUNC);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_011)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, NULL);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_012)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, FIT_NO_FUNC);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_013)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_TIMER;
    config.oc_timer_0.output = CMTW_OUTPUT_MAX;


    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_014)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, NULL);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_015)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, FIT_NO_FUNC);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_016)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_TIMER;
    config.oc_timer_1.output = CMTW_OUTPUT_MAX;


    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_017)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, NULL);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_018)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_CALLBACK;


    err = R_CMTW_Open(channel, &config, FIT_NO_FUNC);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_019)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_TIMER;
    config.ic_timer_0.edge = CMTW_EDGE_MAX;


    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_020)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_CALLBACK;

    err = R_CMTW_Open(channel, &config, NULL);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_021)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_CALLBACK;

    err = R_CMTW_Open(channel, &config, FIT_NO_FUNC);
    TEST_ASSERT_EQUAL(CMTW_ERR_NULL_PTR, err);
}

TEST(CMTW_UNITTEST, TG001_022)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_TIMER;
    config.ic_timer_1.edge = CMTW_EDGE_MAX;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_INVALID_ARG, err);
}

TEST(CMTW_UNITTEST, TG001_023)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_LOCK, err);

    R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));
}

TEST(CMTW_UNITTEST, TG001_024)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_1;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_ENABLED, err);
}

TEST(CMTW_UNITTEST, TG001_025)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_OPENED;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_CLOSED, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG001_026)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_USEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.cm_timer.time = 1;

    config.cm_timer.actions = CMTW_ACTION_CALLBACK;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_OUT_OF_RANGE, err);
}

TEST(CMTW_UNITTEST, TG001_027)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_USEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.oc_timer_0.time = 1;

    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_CALLBACK;
    config.oc_timer_0.output = CMTW_OUTPUT_RETAIN;
    config.oc_timer_1.actions = CMTW_ACTION_NONE;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_OUT_OF_RANGE, err);
}

TEST(CMTW_UNITTEST, TG001_028)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_USEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;
    config.oc_timer_1.time = 1;

    config.cm_timer.actions = CMTW_ACTION_NONE;
    config.oc_timer_0.actions = CMTW_ACTION_NONE;
    config.oc_timer_1.actions = CMTW_ACTION_CALLBACK;
    config.oc_timer_1.output = CMTW_OUTPUT_RETAIN;
    config.ic_timer_0.actions = CMTW_ACTION_NONE;
    config.ic_timer_1.actions = CMTW_ACTION_NONE;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_ERR_OUT_OF_RANGE, err);
}

TEST(CMTW_UNITTEST, TG001_029)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_channel_settings_t config;
    config.time_unit = CMTW_TIME_SEC;
    config.clock_divisor = CMTW_CLK_DIV_512;
    config.clear_source = CMTW_CLR_DISABLED;

    config.cm_timer.actions = CMTW_ACTION_CALLBACK;
    config.cm_timer.time = 1;

    config.oc_timer_0.actions = CMTW_ACTION_CALLBACK;
    config.oc_timer_0.time = 1;
    config.oc_timer_0.output = CMTW_OUTPUT_RETAIN;

    config.oc_timer_1.actions = CMTW_ACTION_CALLBACK;
    config.oc_timer_1.time = 1;
    config.oc_timer_1.output = CMTW_OUTPUT_RETAIN;

    config.ic_timer_0.actions = CMTW_ACTION_CALLBACK;
    config.ic_timer_0.edge = CMTW_EDGE_ANY;

    config.ic_timer_1.actions = CMTW_ACTION_CALLBACK;
    config.ic_timer_1.edge = CMTW_EDGE_ANY;

    err = R_CMTW_Open(channel, &config, callback);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);
}

/*****************************
 * R_CMTW_Control() test cases
 * TG002_001 -> TG002_013
 ******************************/

TEST(CMTW_UNITTEST, TG002_001)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_MAX;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_BAD_CHAN, err);
}

TEST(CMTW_UNITTEST, TG002_002)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_MAX;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_UNKNOWN_CMD, err);
}

TEST(CMTW_UNITTEST, TG002_003)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_LOCK, err);

    R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));
}

TEST(CMTW_UNITTEST, TG002_004)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_1;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_ENABLED, err);
}

TEST(CMTW_UNITTEST, TG002_005)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_OPENED, err);
}

TEST(CMTW_UNITTEST, TG002_006)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_OPENED;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_RUNNIG, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_007)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_START;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_RUNNING;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_STOPPED, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_008)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_RESUME;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_RUNNING;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_STOPPED, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_009)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_RESTART;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = (cmtw_prv_channel_state_t)3;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_010)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_START;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_OPENED;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_011)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_RESUME;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_OPENED;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_012)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_STOP;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_RUNNING;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

TEST(CMTW_UNITTEST, TG002_013)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;
    cmtw_cmd_t cmd = CMTW_CMD_RESTART;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_RUNNING;

    err = R_CMTW_Control(channel, cmd);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);

    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;
}

/*****************************
 * R_CMTW_Close() test cases
 * TG003_001 -> TG003_005
 ******************************/

TEST(CMTW_UNITTEST, TG003_001)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_MAX;

    err = R_CMTW_Close(channel);
    TEST_ASSERT_EQUAL(CMTW_ERR_BAD_CHAN, err);
}

TEST(CMTW_UNITTEST, TG003_002)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;

    R_BSP_HardwareLock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));

    err = R_CMTW_Close(channel);
    TEST_ASSERT_EQUAL(CMTW_ERR_LOCK, err);

    R_BSP_HardwareUnlock((mcu_lock_t)(BSP_LOCK_CMTW0 + channel));
}

TEST(CMTW_UNITTEST, TG003_003)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_1;

    err = R_CMTW_Close(channel);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_ENABLED, err);
}

TEST(CMTW_UNITTEST, TG003_004)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_CLOSED;

    err = R_CMTW_Close(channel);
    TEST_ASSERT_EQUAL(CMTW_ERR_CH_NOT_OPENED, err);
}

TEST(CMTW_UNITTEST, TG003_005)
{
    cmtw_err_t err;
    cmtw_channel_t channel = CMTW_CHANNEL_0;

    cmtw_prv_ch_ctrl_info_t *hdl;
    hdl = g_cmtw_handles[channel];
    hdl->state = CMTW_PRV_CHANNEL_STATE_OPENED;

    err = R_CMTW_Close(channel);
    TEST_ASSERT_EQUAL(CMTW_SUCCESS, err);
}

/*****************************
 * R_CMTW_GetVersion() test cases
 * TG004_001
 ******************************/

TEST(CMTW_UNITTEST, TG004_001)
{
    uint32_t expect_version = (((uint32_t)CMTW_RX_VERSION_MAJOR) << 16) | (uint32_t)CMTW_RX_VERSION_MINOR;
    uint32_t actual_version;
    actual_version = R_CMTW_GetVersion();
    TEST_ASSERT_EQUAL(expect_version, actual_version);
}
