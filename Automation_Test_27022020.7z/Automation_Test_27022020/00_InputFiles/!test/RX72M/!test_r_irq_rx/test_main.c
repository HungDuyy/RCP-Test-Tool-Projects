/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2014 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name	   : test_main.c
* Description  : Unity unit tests for <Module Name>
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 29.06.2018 1.00     First Release
*                               Added support RX65N, RX65N-2MB, RX66T-L, RX72T, RX72M
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "platform.h"
#include "r_irq_rx_if.h"
#include "unity_fixture.h"

#include "r_smc_entry.h"
#include "r_irq_rx_pinset.h"


/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static void RunAllTests(void);

#define IGNORE_INTERRUPTS_TEST_CASE	1

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/

TEST_GROUP_RUNNER(R_IRQ_Open_Test)
{
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_1);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_2);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_3);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_4);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_5);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_6);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_7);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_8);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_9);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_10);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_11);
	RUN_TEST_CASE(R_IRQ_Open_Test, TG001_12);
}

TEST_GROUP_RUNNER(R_IRQ_Control_Test)
{
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_1);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_2);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_3);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_4);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_5);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_6);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_7);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_8);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_9);
	RUN_TEST_CASE(R_IRQ_Control_Test, TG002_10);
}

TEST_GROUP_RUNNER(R_IRQ_Close_Test)
{
	RUN_TEST_CASE(R_IRQ_Close_Test, TG003_1);
	RUN_TEST_CASE(R_IRQ_Close_Test, TG003_2);
	RUN_TEST_CASE(R_IRQ_Close_Test, TG003_3);
	RUN_TEST_CASE(R_IRQ_Close_Test, TG003_4);
	RUN_TEST_CASE(R_IRQ_Close_Test, TG003_5);
}

TEST_GROUP_RUNNER(R_IRQ_ReadInput_Test)
{
	RUN_TEST_CASE(R_IRQ_ReadInput_Test, TG004_1);
	RUN_TEST_CASE(R_IRQ_ReadInput_Test, TG004_2);
	RUN_TEST_CASE(R_IRQ_ReadInput_Test, TG004_3);
	RUN_TEST_CASE(R_IRQ_ReadInput_Test, TG004_4);
	RUN_TEST_CASE(R_IRQ_ReadInput_Test, TG004_5);
}

TEST_GROUP_RUNNER(R_IRQ_InterruptEnable_Test)
{
	RUN_TEST_CASE(R_IRQ_InterruptEnable_Test, TG005_1);
	RUN_TEST_CASE(R_IRQ_InterruptEnable_Test, TG005_2);
	RUN_TEST_CASE(R_IRQ_InterruptEnable_Test, TG005_3);
	RUN_TEST_CASE(R_IRQ_InterruptEnable_Test, TG005_4);
	RUN_TEST_CASE(R_IRQ_InterruptEnable_Test, TG005_5);
}

TEST_GROUP_RUNNER(R_IRQ_GetVersion_Test)
{
	RUN_TEST_CASE(R_IRQ_GetVersion_Test, TG006_1);
}

/***********************************************************************************************************************
* Function Name: RunAllTests
* Description  : Call test groups
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
static void RunAllTests(void)
{
	RUN_TEST_GROUP(R_IRQ_Open_Test);
	RUN_TEST_GROUP(R_IRQ_Control_Test);
	RUN_TEST_GROUP(R_IRQ_Close_Test);
	RUN_TEST_GROUP(R_IRQ_ReadInput_Test);
	RUN_TEST_GROUP(R_IRQ_InterruptEnable_Test);
	RUN_TEST_GROUP(R_IRQ_GetVersion_Test);
}
/***********************************************************************************************************************
End of function RunAllTests
***********************************************************************************************************************/

void main()
{
	R_ICU_PinSet();
    UnityMain(0, 0, RunAllTests);
    printf("Unit Test completed\r\n");
}
/***********************************************************************************************************************
End of function main
***********************************************************************************************************************/


