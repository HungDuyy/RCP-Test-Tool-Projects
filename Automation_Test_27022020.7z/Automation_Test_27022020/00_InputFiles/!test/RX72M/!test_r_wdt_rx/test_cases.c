/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name    : test_cases.c
* Description  : Test scripts of WDT RX72M unit test
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 28.05.2018 1.00		First release
***********************************************************************************************************************/

#include "platform.h"
#include "r_wdt_rx_if.h"

#include <stdio.h>
#include "unity.h"
#include "unity_fixture.h"


TEST_GROUP(WTD_TEST);

/***********************************************************************************************************************
* Function Name: WDT_TEST_SETUP
* Description  :
***********************************************************************************************************************/
TEST_SETUP(WDT_TEST)
{
	/* DO SOMETHING */
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: WDT_TEST_TEARDOWN
* Description  :
***********************************************************************************************************************/
TEST_TEAR_DOWN(WDT_TEST)
{
	/* DO SOMETHING */
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG001_001
* Description  : WDT Get Version
***********************************************************************************************************************/
TEST(WDT_TEST, TG001_001)
{
	uint32_t ret = R_WDT_GetVersion();
	printf("[TG001_001]===");
	uint32_t ver = (uint32_t)((WDT_RX_VERSION_MAJOR << 16) | WDT_RX_VERSION_MINOR);

	TEST_ASSERT_EQUAL(ver, ret);
	if(ret == ver)
	{
		printf("Version of WDT is: %d.%d", WDT_RX_VERSION_MAJOR, WDT_RX_VERSION_MINOR);
	}
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_001
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_001)
{
	wdt_config_t * p_cfg = NULL;
	printf("[TG002_001]===");

	wdt_err_t err = R_WDT_Open((void*)p_cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_NULL_PTR, err);

	printf("WDT configuration is NULL");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_002
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_002)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_NUM_TIMEOUTS;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;

	printf("[TG002_002]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("WDT Time-Out Period is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_003
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_003)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = (wdt_timeout_control_t)(WDT_TIMEOUT_NMI + 1);
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;

	printf("[TG002_003]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("Signal control is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_004
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_004)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = (wdt_clock_div_t)(WDT_CLOCK_DIV_8192 + 1);
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;

	printf("[TG002_004]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("WDT Clock Division Ratio is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_005)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = (wdt_window_end_t)(WDT_WINDOW_END_0 + 1);
	cfg.window_start = WDT_WINDOW_START_100;

	printf("[TG002_005]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("Window End Position is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_006
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_006)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = (wdt_window_start_t)(WDT_WINDOW_START_100 + 1);

	printf("[TG002_006]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("Window Start Position is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_007
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_007)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;

	bool bsp_err = R_BSP_HardwareLock(BSP_LOCK_WDT);
	TEST_ASSERT_EQUAL(true, bsp_err);

	printf("[TG002_007]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_BUSY, err);

	printf("Fail to get the lock");
	printf("\n");

	R_BSP_HardwareUnlock(BSP_LOCK_WDT);
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_008
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_008)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;

	uint16_t ret = (uint16_t)((WDT_TIMEOUT_1024 | WDT_CLOCK_DIV_4) | (WDT_WINDOW_END_0 | WDT_WINDOW_START_100));

	printf("[TG002_008]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(ret, WDT.WDTCR.WORD);
	TEST_ASSERT_EQUAL((uint8_t)WDT_TIMEOUT_NMI, WDT.WDTRCR.BYTE);
	TEST_ASSERT_EQUAL(0x1, ICU.NMIER.BIT.WDTEN);
	TEST_ASSERT_EQUAL(WDT_SUCCESS, err);

	printf("Open success");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG002_009
* Description  : WDT_Open test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG002_009)
{
	wdt_config_t cfg;
	cfg.timeout = WDT_TIMEOUT_1024;
	cfg.timeout_control = WDT_TIMEOUT_NMI;
	cfg.wdtcks_div = WDT_CLOCK_DIV_4;
	cfg.window_end = WDT_WINDOW_END_0;
	cfg.window_start = WDT_WINDOW_START_100;


	printf("[TG002_009]===");

	wdt_err_t err = R_WDT_Open((void*)&cfg);
	TEST_ASSERT_EQUAL(WDT_ERR_OPEN_IGNORED, err);

	printf("Already Opened");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_001
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_001)
{
	wdt_cmd_t cmd = (wdt_cmd_t)(WDT_CMD_REFRESH_COUNTING + 1);
	uint16_t * p_status = NULL;

	printf("[TG003_001]===");

	wdt_err_t err = R_WDT_Control(cmd, p_status);
	TEST_ASSERT_EQUAL(WDT_ERR_INVALID_ARG, err);

	printf("Command is invalid");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_002
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_002)
{
	wdt_cmd_t cmd = WDT_CMD_GET_STATUS;
	uint16_t * p_status = NULL;

	printf("[TG003_002]===");

	wdt_err_t err = R_WDT_Control(cmd, p_status);
	TEST_ASSERT_EQUAL(WDT_ERR_NULL_PTR, err);

	printf("Null pointer");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_003
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_003)
{
	wdt_cmd_t cmd = WDT_CMD_GET_STATUS;
	uint16_t status;

	bool bsp_err = R_BSP_HardwareLock(BSP_LOCK_WDT);
	TEST_ASSERT_EQUAL(true, bsp_err);

	printf("[TG003_003]===");

	wdt_err_t err = R_WDT_Control(cmd, &status);
	TEST_ASSERT_EQUAL(WDT_ERR_BUSY, err);

	printf("Fail to get the lock");
	printf("\n");
	R_BSP_HardwareUnlock(BSP_LOCK_WDT);
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_004
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_004)
{
	wdt_cmd_t cmd = WDT_CMD_REFRESH_COUNTING;
	uint16_t status;

	printf("[TG003_004]===");

	wdt_err_t err = R_WDT_Control(cmd, &status);
	TEST_ASSERT_EQUAL(0xFFu, WDT.WDTRR);
	TEST_ASSERT_EQUAL(WDT_SUCCESS, err);

	printf("Reset counting");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_005
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_005)
{
	wdt_cmd_t cmd = WDT_CMD_GET_STATUS;
	uint16_t status;

	printf("[TG003_005]===");

	wdt_err_t err = R_WDT_Control(cmd, &status);

	TEST_ASSERT_EQUAL(WDT.WDTSR.WORD, status);
	TEST_ASSERT_EQUAL(WDT_SUCCESS, err);

	printf("Get Status");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TG003_006
* Description  : WDT_Control test case
***********************************************************************************************************************/
TEST(WDT_TEST, TG003_006)
{
	wdt_cmd_t cmd = WDT_CMD_GET_STATUS;
	uint16_t status;

	printf("[TG003_006]===");

	wdt_err_t err = R_WDT_Control(cmd, &status);
	TEST_ASSERT_EQUAL(WDT_ERR_NOT_OPENED, err);

	printf("WDT not open");
	printf("\n");
}
/***********************************************************************************************************************
End of function
***********************************************************************************************************************/

