/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_main.c
* Description     : Unity unit tests for RSCAN Module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 18.01.2019 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "platform.h"
#include "unity_fixture.h"


/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static void RunAllTests(void);

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/

TEST_GROUP_RUNNER(R_CAN_Create_Test)
{
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_001);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_002);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_003);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_004);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_005);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_006);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_007);
    RUN_TEST_CASE(R_CAN_Create_Test, TG001_008);
}

TEST_GROUP_RUNNER(R_CAN_PortSet_Test)
{
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_001);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_002);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_003);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_004);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_005);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_006);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_007);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_008);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_009);
    RUN_TEST_CASE(R_CAN_PortSet_Test, TG002_010);
}

TEST_GROUP_RUNNER(R_CAN_Control_Test)
{
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_001);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_002);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_003);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_004);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_005);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_006);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_007);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_008);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_009);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_010);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_011);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_012);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_013);
    RUN_TEST_CASE(R_CAN_Control_Test, TG003_014);
}

TEST_GROUP_RUNNER(R_CAN_TxSet_Test)
{
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_001);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_002);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_003);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_004);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_005);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_006);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_007);
    RUN_TEST_CASE(R_CAN_TxSet_Test, TG004_008);
}

TEST_GROUP_RUNNER(R_CAN_TxSetXid_Test)
{
    RUN_TEST_CASE(R_CAN_TxSetXid_Test, TG005_001);
    RUN_TEST_CASE(R_CAN_TxSetXid_Test, TG005_002);
    RUN_TEST_CASE(R_CAN_TxSetXid_Test, TG005_003);
    RUN_TEST_CASE(R_CAN_TxSetXid_Test, TG005_004);
    RUN_TEST_CASE(R_CAN_TxSetXid_Test, TG005_005);
}

TEST_GROUP_RUNNER(R_CAN_Tx_Test)
{
    RUN_TEST_CASE(R_CAN_Tx_Test, TG006_001);
    RUN_TEST_CASE(R_CAN_Tx_Test, TG006_002);
    RUN_TEST_CASE(R_CAN_Tx_Test, TG006_003);
    RUN_TEST_CASE(R_CAN_Tx_Test, TG006_004);
    RUN_TEST_CASE(R_CAN_Tx_Test, TG006_005);
}

TEST_GROUP_RUNNER(R_CAN_TxCheck_Test)
{
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_001);
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_002);
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_003);
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_004);
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_005);
    RUN_TEST_CASE(R_CAN_TxCheck_Test, TG007_006);
}

TEST_GROUP_RUNNER(R_CAN_TxStopMsg_Test)
{
    RUN_TEST_CASE(R_CAN_TxStopMsg_Test, TG008_001);
    RUN_TEST_CASE(R_CAN_TxStopMsg_Test, TG008_002);
    RUN_TEST_CASE(R_CAN_TxStopMsg_Test, TG008_003);
    RUN_TEST_CASE(R_CAN_TxStopMsg_Test, TG008_004);
    RUN_TEST_CASE(R_CAN_TxStopMsg_Test, TG008_005);
}

TEST_GROUP_RUNNER(R_CAN_RxSet_Test)
{
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_001);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_002);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_003);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_004);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_005);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_006);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_007);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_008);
    RUN_TEST_CASE(R_CAN_RxSet_Test, TG009_009);
}

TEST_GROUP_RUNNER(R_CAN_RxSetXid_Test)
{
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_001);
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_002);
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_003);
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_004);
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_005);
    RUN_TEST_CASE(R_CAN_RxSetXid_Test, TG010_006);

}

TEST_GROUP_RUNNER(R_CAN_RxPoll_Test)
{
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_001);
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_002);
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_003);
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_004);
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_005);
    RUN_TEST_CASE(R_CAN_RxPoll_Test, TG011_006);

}

TEST_GROUP_RUNNER(R_CAN_RxRead_Test)
{
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_001);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_002);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_003);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_004);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_005);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_006);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_007);
    RUN_TEST_CASE(R_CAN_RxRead_Test, TG012_008);
}

TEST_GROUP_RUNNER(R_CAN_RxSetMask_Test)
{
    RUN_TEST_CASE(R_CAN_RxSetMask_Test, TG013_001);
    RUN_TEST_CASE(R_CAN_RxSetMask_Test, TG013_002);
    RUN_TEST_CASE(R_CAN_RxSetMask_Test, TG013_003);
    RUN_TEST_CASE(R_CAN_RxSetMask_Test, TG013_004);
    RUN_TEST_CASE(R_CAN_RxSetMask_Test, TG013_005);
}

TEST_GROUP_RUNNER(R_CAN_CheckErr_Test)
{
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_001);
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_002);
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_003);
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_004);
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_005);
    RUN_TEST_CASE(R_CAN_CheckErr_Test, TG014_006);
}

TEST_GROUP_RUNNER(R_CAN_SetBitrate_Test)
{
    RUN_TEST_CASE(R_CAN_SetBitrate_Test, TG015_001);
    RUN_TEST_CASE(R_CAN_SetBitrate_Test, TG015_002);
    RUN_TEST_CASE(R_CAN_SetBitrate_Test, TG015_003);
    RUN_TEST_CASE(R_CAN_SetBitrate_Test, TG015_004);
}

TEST_GROUP_RUNNER(can_wait_tx_rx_Test)
{
    RUN_TEST_CASE(can_wait_tx_rx_Test, TG016_001);
    RUN_TEST_CASE(can_wait_tx_rx_Test, TG016_002);
}

/***********************************************************************************************************************
* Function Name: RunAllTests
* Description  : Call test groups
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
static void RunAllTests(void)
{
    /* Run each test group. */
    printf("RUN TEST GROUP: UT_R_CAN_Create_Test\n");
    RUN_TEST_GROUP(R_CAN_Create_Test);
    printf("END TEST GROUP: UT_R_CAN_Create_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: UT_R_CAN_PortSet_Test\n");
    RUN_TEST_GROUP(R_CAN_PortSet_Test);
    printf("END TEST GROUP: UT_R_CAN_PortSet_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_Control_Test\n");
    RUN_TEST_GROUP(R_CAN_Control_Test);
    printf("END TEST GROUP: R_CAN_Control_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_TxSet_Test\n");
    RUN_TEST_GROUP(R_CAN_TxSet_Test);
    printf("END TEST GROUP: R_CAN_TxSet_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_TxSetXid_Test\n");
    RUN_TEST_GROUP(R_CAN_TxSetXid_Test);
    printf("END TEST GROUP: R_CAN_TxSetXid_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_Tx_Test\n");
    RUN_TEST_GROUP(R_CAN_Tx_Test);
    printf("END TEST GROUP: R_CAN_Tx_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_TxCheck_Test\n");
    RUN_TEST_GROUP(R_CAN_TxCheck_Test);
    printf("END TEST GROUP: R_CAN_TxCheck_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_TxStopMsg_Test\n");
    RUN_TEST_GROUP(R_CAN_TxStopMsg_Test);
    printf("END TEST GROUP: R_CAN_TxStopMsg_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_RxSet_Test\n");
    RUN_TEST_GROUP(R_CAN_RxSet_Test);
    printf("END TEST GROUP: R_CAN_RxSet_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_RxSetXid_Test\n");
    RUN_TEST_GROUP(R_CAN_RxSetXid_Test);
    printf("END TEST GROUP: R_CAN_RxSetXid_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_RxPoll_Test\n");
    RUN_TEST_GROUP(R_CAN_RxPoll_Test);
    printf("END TEST GROUP: R_CAN_RxPoll_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_RxRead_Test\n");
    RUN_TEST_GROUP(R_CAN_RxRead_Test);
    printf("END TEST GROUP: R_CAN_RxRead_Test\n\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_RxSetMask_Test\n");
    RUN_TEST_GROUP(R_CAN_RxSetMask_Test);
    printf("END TEST GROUP: R_CAN_RxSetMask_Test\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_CheckErr_Test\n");
    RUN_TEST_GROUP(R_CAN_CheckErr_Test);
    printf("END TEST GROUP: R_CAN_CheckErr_Test\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: R_CAN_SetBitrate_Test\n");
    RUN_TEST_GROUP(R_CAN_SetBitrate_Test);
    printf("END TEST GROUP: R_CAN_SetBitrate_Test\n");

    /* Run each test group. */
    printf("RUN TEST GROUP: can_wait_tx_rx_Test\n");
    RUN_TEST_GROUP(can_wait_tx_rx_Test);
    printf("END TEST GROUP: can_wait_tx_rx_Test\n");
}
/***********************************************************************************************************************
End of function RunAllTests
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/

void main()
{
    UnityMain(0, 0, RunAllTests);

    while(1)
    {
        /* Infinite loop. */
    }
}
/***********************************************************************************************************************
End of function main
***********************************************************************************************************************/
