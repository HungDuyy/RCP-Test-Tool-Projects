/*
 * TestCases.h
 *
 *  Created on: 30 Jan 2019
 *      Author: a5112356
 */

#ifndef TESTCASES_TESTCASES_H_
#define TESTCASES_TESTCASES_H_

#include "r_can_rx_if.h"


typedef enum e_tc_err      /* TestCase error codes */
{
    TC_SUCCESS = 0,
    TC_ERROR
} tc_err_t;


extern tc_err_t TC001_Main(void);
extern tc_err_t TC002_Main(void);
extern tc_err_t TC003_Main(void);
extern tc_err_t TC004_Main(void);
extern tc_err_t TC005_Main(void);
extern tc_err_t TC006_Main(void);
extern tc_err_t TC007_Main(void);
extern tc_err_t TC008_Main(void);
extern tc_err_t TC009_Main(void);
extern tc_err_t TC010_Main(void);
extern tc_err_t TC011_Main(void);
extern tc_err_t TC012_Main(void);
extern tc_err_t TC013_Main(void);
extern tc_err_t TC014_Main(void);
extern tc_err_t TC015_Main(void);
extern tc_err_t TC016_Main(void);

#endif /* TESTCASES_TESTCASES_H_ */
