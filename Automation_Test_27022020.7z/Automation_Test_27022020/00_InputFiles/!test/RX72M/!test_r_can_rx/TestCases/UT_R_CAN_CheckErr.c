#include "test_main.h"

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_CheckErr_Test)
{
	const uint32_t ch_nr = 0;
	R_CAN_Create(ch_nr, NULL, NULL, NULL);

	const uint32_t ch_nr1 = 1;
	R_CAN_Create(ch_nr1, NULL, NULL, NULL);

	const uint32_t ch_nr2 = 2;
	R_CAN_Create(ch_nr2, NULL, NULL, NULL);


}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_CheckErr_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1= 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2= 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG014_001
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_001)
{
	printf("[TG014_001]\n");
    const uint32_t ch_nr = 0;
	uint32_t api_status = R_CAN_OK;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_STATUS_ERROR_ACTIVE,api_status);

}

/***********************************************************************************************************************
* Function Name: TG014_002
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_002)
{
	printf("[TG014_002]\n");
    const uint32_t ch_nr = 1;
	uint32_t api_status = R_CAN_OK;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_STATUS_ERROR_ACTIVE,api_status);

}

/***********************************************************************************************************************
* Function Name: TG014_003
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_003)
{
	printf("[TG014_003]\n");
    const uint32_t ch_nr = 2;
	uint32_t api_status = R_CAN_OK;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_STATUS_ERROR_ACTIVE,api_status);

}

/***********************************************************************************************************************
* Function Name: TG014_004
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_004)
{
	printf("[TG014_004]\n");
    const uint32_t ch_nr = 3;
	uint32_t api_status = R_CAN_OK;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR,api_status);

}

/***********************************************************************************************************************
* Function Name: TG014_005
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_005)
{
	printf("[TG014_005]\n");
    const uint32_t ch_nr = 0;
	uint32_t api_status = R_CAN_OK;


    CAN0.STR.BIT.EST = 1;
    CAN0.STR.BIT.EPST = 1;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_STATUS_ERROR_PASSIVE,api_status);
    CAN0.STR.BIT.EST = 0;
    CAN0.STR.BIT.EPST = 0;

}


/***********************************************************************************************************************
* Function Name: TG014_006
* Description  : Test API function R_CAN_CheckErr()
***********************************************************************************************************************/
TEST(R_CAN_CheckErr_Test, TG014_006)
{
	printf("[TG014_006]\n");
    const uint32_t ch_nr = 0;
	uint32_t api_status = R_CAN_OK;

    CAN0.STR.BIT.EST = 1;
    CAN0.STR.BIT.BOST = 1;

	api_status = R_CAN_CheckErr(ch_nr);
	TEST_ASSERT_EQUAL(R_CAN_STATUS_BUSOFF,api_status);
    CAN0.STR.BIT.EST = 0;
    CAN0.STR.BIT.BOST = 0;

}
