
#include "test_main.h"


/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_PortSet_Test)
{
	uint32_t channel= 0;
   R_CAN_Create(channel, NULL, NULL, NULL);

}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_PortSet_Test)
{
    /* do nothing */
}



/***********************************************************************************************************************
* Function Name: TG002_001
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_001)
{
	printf("[TG002_001]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = ENABLE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}


/***********************************************************************************************************************
* Function Name: TG002_002
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_002)
{
	printf("[TG002_002]\n");
    uint32_t ch_nr = 1;
    uint32_t action_type = ENABLE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}


/***********************************************************************************************************************
* Function Name: TG002_003
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_003)
{
	printf("[TG002_003]\n");
    uint32_t ch_nr = 2;
    uint32_t action_type = ENABLE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}


/***********************************************************************************************************************
* Function Name: TG002_004
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_004)
{
	printf("[TG002_004]\n");
    uint32_t ch_nr = 4;
    uint32_t action_type = ENABLE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_005
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_005)
{
	printf("[TG002_005]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = DISABLE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_006
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_006)
{
	printf("[TG002_006]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = CANPORT_TEST_LISTEN_ONLY;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_007
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_007)
{
	printf("[TG002_007]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = CANPORT_TEST_0_EXT_LOOPBACK;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_008
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_008)
{
	printf("[TG002_008]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = CANPORT_TEST_1_INT_LOOPBACK;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_009
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_009)
{
	printf("[TG002_009]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = CANPORT_RETURN_TO_NORMAL;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG002_010
* Description  : Test API function R_CAN_PortSet()
***********************************************************************************************************************/
TEST(R_CAN_PortSet_Test, TG002_010)
{
	printf("[TG002_010]\n");
    uint32_t ch_nr = 0;
    uint32_t action_type = EXITSLEEP_CANMODE;
    uint32_t api_status = R_CAN_OK;

    api_status = R_CAN_PortSet(ch_nr, action_type);
    TEST_ASSERT_EQUAL(R_CAN_BAD_ACTION_TYPE, api_status);
}
