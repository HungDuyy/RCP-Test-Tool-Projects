#include "test_main.h"

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(R_CAN_RxRead_Test)
{
	const uint32_t ch_nr = 0;
	R_CAN_Create(ch_nr, NULL, NULL, NULL);

	const uint32_t ch_nr1 = 1;
	R_CAN_Create(ch_nr1, NULL, NULL, NULL);

	const uint32_t ch_nr2 = 2;
	R_CAN_Create(ch_nr2, NULL, NULL, NULL);


}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(R_CAN_RxRead_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1= 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2= 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG012_001
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_001)
{
	printf("[TG012_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
	const uint32_t pkt_id = 0xA1;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	can_frame_t frame;
	frame.id = pkt_id;
	frame.dlc= pkt_length;
	for (uint8_t i = 0; i < pkt_length; i++)
	{
		frame.data[i] = i + 'A';
	}
	CAN0.CTLR.BIT.IDFM = EXT_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);

}

/***********************************************************************************************************************
* Function Name: TG012_002
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_002)
{
	printf("[TG012_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
    can_frame_t frame;
	const uint32_t pkt_id = 0xA1;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	 frame.id = pkt_id;
	 frame.dlc= pkt_length;
	 for (uint8_t i = 0; i < pkt_length; i++)
	  {
	        frame.data[i] = i + 'A';
	 }

	CAN1.CTLR.BIT.IDFM = STD_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_003
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_003)
{
	printf("[TG012_003]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    can_frame_t frame;
	const uint32_t pkt_id = 0xA1;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	 frame.id = pkt_id;
	 frame.dlc= pkt_length;
	 for (uint8_t i = 0; i < pkt_length; i++)
	  {
	        frame.data[i] = i + 'A';
	 }

	CAN2.CTLR.BIT.IDFM = MIXED_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_004
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_004)
{
	printf("[TG012_004]\n");
    const uint32_t ch_nr = 3;
    const uint32_t mbox_nr = 0;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_BAD_CH_NR, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_005
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_005)
{
	printf("[TG012_005]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 32;
    uint32_t api_status = R_CAN_OK;
    can_frame_t frame;

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_SW_BAD_MBX, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_006
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_006)
{
	printf("[TG012_006]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
	const uint32_t pkt_id = 0xA1;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	can_frame_t frame;
	frame.id = pkt_id;
	frame.dlc= pkt_length;

	CAN0.CTLR.BIT.IDFM = EXT_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
    TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_007
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_007)
{
	printf("[TG012_007]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    can_frame_t frame;
	const uint32_t pkt_id = 0xE0000000;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	 frame.id = pkt_id;
	 frame.dlc= pkt_length;
	 for (uint8_t i = 0; i < pkt_length; i++)
	  {
	        frame.data[i] = i + 'A';
	 }

	CAN2.CTLR.BIT.IDFM = MIXED_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_OK, api_status);
}

/***********************************************************************************************************************
* Function Name: TG012_008
* Description  : Test API function R_CAN_RxRead()
***********************************************************************************************************************/
TEST(R_CAN_RxRead_Test, TG012_008)
{
	printf("[TG012_008]\n");
    const uint32_t ch_nr = 2;
    const uint32_t mbox_nr = 2;
    can_frame_t frame;
	const uint32_t pkt_id = 0xE0000000;
	const uint8_t pkt_length = 8;
	const uint32_t frame_type = DATA_FRAME;
    uint32_t api_status = R_CAN_OK;

	 frame.id = pkt_id;
	 frame.dlc= pkt_length;
	 for (uint8_t i = 0; i < pkt_length; i++)
	  {
	        frame.data[i] = i + 'A';
	 }

	CAN2.CTLR.BIT.IDFM = MIXED_ID_MODE;
	R_CAN_PortSet(ch_nr, CANPORT_TEST_1_INT_LOOPBACK);
	R_CAN_TxSet(ch_nr, mbox_nr, &frame, frame_type);

	CAN2.MCTL[mbox_nr].BIT.RX.MSGLOST = 1;
    api_status = R_CAN_RxRead(ch_nr, mbox_nr,&frame);
	TEST_ASSERT_EQUAL(R_CAN_MSGLOST, api_status);
}

