#include "test_main.h"

/***********************************************************************************************************************
* Function Name: TEST_SETUP
* Description  : Setup for these unit tests. This will be run before every test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_SETUP(can_wait_tx_rx_Test)
{
	const uint32_t ch_nr = 0;
	R_CAN_Create(ch_nr, NULL, NULL, NULL);

	const uint32_t ch_nr1 = 1;
	R_CAN_Create(ch_nr1, NULL, NULL, NULL);

	const uint32_t ch_nr2 = 2;
	R_CAN_Create(ch_nr2, NULL, NULL, NULL);


}

/***********************************************************************************************************************
* Function Name: TEST_TEAR_DOWN
* Description  : Tear down for these unit tests. This will be run after each test case.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
TEST_TEAR_DOWN(can_wait_tx_rx_Test)
{
	uint32_t ch_nr= 0;
    R_CAN_Control(ch_nr, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr, DISABLE);

	uint32_t ch_nr1= 1;
    R_CAN_Control(ch_nr1, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr1, DISABLE);

	uint32_t ch_nr2= 2;
    R_CAN_Control(ch_nr2, OPERATE_CANMODE);
    R_CAN_PortSet(ch_nr2, DISABLE);
}

/***********************************************************************************************************************
* Function Name: TG016_001
* Description  : Test API function can_wait_tx_rx()
***********************************************************************************************************************/
TEST(can_wait_tx_rx_Test, TG016_001)
{
	printf("[TG016_001]\n");
    const uint32_t ch_nr = 0;
    const uint32_t mbox_nr = 0;
    uint32_t api_status = R_CAN_OK;


    CAN0.MCTL[0].BIT.TX.TRMREQ = 1;
    api_status =  R_CAN_Tx(ch_nr, mbox_nr);
    TEST_ASSERT_EQUAL(R_CAN_SW_SET_TX_TMO, api_status);
    CAN0.MCTL[0].BIT.TX.TRMREQ = 0;
}

/***********************************************************************************************************************
* Function Name: TG016_002
* Description  : Test API function can_wait_tx_rx()
***********************************************************************************************************************/
TEST(can_wait_tx_rx_Test, TG016_002)
{
	printf("[TG016_002]\n");
    const uint32_t ch_nr = 1;
    const uint32_t mbox_nr = 1;
    uint32_t api_status = R_CAN_OK;


    CAN1.MCTL[1].BIT.RX.RECREQ = 1;
    CAN1.MCTL[1].BIT.RX.INVALDATA = 1;
    api_status =  R_CAN_Tx(ch_nr, mbox_nr);
    TEST_ASSERT_EQUAL(R_CAN_SW_SET_RX_TMO, api_status);
}
