/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name       : test_cases.c
* Description     : Unity unit tests for RX RSCAN module
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 18.01.2019 1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "platform.h"
#include "unity_fixture.h"
#include "r_can_rx_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/


/***********************************************************************************************************************
Imported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
/* Declare test groups. */
TEST_GROUP(R_CAN_Create);
TEST_GROUP(R_CAN_PortSet);
TEST_GROUP(R_CAN_Control);
TEST_GROUP(R_CAN_SetBitrate);
TEST_GROUP(R_CAN_TxSet);
TEST_GROUP(R_CAN_TxSetXid);
TEST_GROUP(R_CAN_Tx);
TEST_GROUP(R_CAN_TxCheck);
TEST_GROUP(R_CAN_TxStopMsg);
TEST_GROUP(R_CAN_RxSet);
TEST_GROUP(R_CAN_RxSetXid);
TEST_GROUP(R_CAN_RxPoll);
TEST_GROUP(R_CAN_RxRead);
TEST_GROUP(R_CAN_RxSetMask);
TEST_GROUP(R_CAN_CheckErr);
TEST_GROUP(can_wait_tx_rx);
TEST_GROUP(config_can_interrupts);
TEST_GROUP(universal_can_callback);
TEST_GROUP(can_module_stop_state_cancel);


